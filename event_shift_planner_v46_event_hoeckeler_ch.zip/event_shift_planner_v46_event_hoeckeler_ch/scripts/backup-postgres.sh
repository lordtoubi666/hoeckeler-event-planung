#!/usr/bin/env sh
set -eu
BACKUP_DIR="${BACKUP_DIR:-./backups}"
mkdir -p "$BACKUP_DIR"
stamp="$(date +%Y%m%d_%H%M%S)"
out="$BACKUP_DIR/hoeckeler_${stamp}.sql.gz"
docker compose --env-file .env.production -f docker-compose.production.yml exec -T db   pg_dump -U "${POSTGRES_USER:-hoeckeler}" "${POSTGRES_DB:-hoeckeler}" | gzip > "$out"
find "$BACKUP_DIR" -type f -name 'hoeckeler_*.sql.gz' -mtime +30 -delete
echo "$out"
