window.HOECKELER_CONFIG = {
  API_BASE_URL: "https://api.event.hoeckeler.ch",
  ENV_NAME: "production",
  TEST_SYSTEM: false
};
