
function applyTheme(theme){
  const dark=theme==='dark';
  document.body.classList.toggle('dark',dark);
  const icon=$('#themeIcon'),label=$('#themeLabel');
  if(icon)icon.textContent=dark?'☀️':'🌙';
  if(label)label.textContent=dark?'Hellmodus':'Dunkelmodus';
}
function initTheme(){
  const saved=localStorage.getItem('eventPlannerTheme');
  if(saved==='dark'||saved==='light') applyTheme(saved);
  else applyTheme('dark');
}
function toggleTheme(){
  const next=document.body.classList.contains('dark')?'light':'dark';
  localStorage.setItem('eventPlannerTheme',next);
  applyTheme(next);
}


let state={events:[],people:[],shifts:[],assignments:[],templates:[],users:[],availability:[],swaps:[],notifications:[],confirmations:[],waitlist:[],signup_requests:[],event_people:[],skills:[],person_skills:[],shift_skills:[],settings:{min_rest_hours:8,weekly_warning_hours:40},current_user:null};
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const APP_CONFIG=window.HOECKELER_CONFIG||{};
const API_BASE=(APP_CONFIG.API_BASE_URL||'').replace(/\/$/,'');
let csrfToken='';
const apiUrl=url=>/^https?:\/\//i.test(url)?url:(API_BASE&&url.startsWith('/')?API_BASE+url:url);
const api=async(url,opts={})=>{
  const method=(opts.method||'GET').toUpperCase();
  const headers={'Content-Type':'application/json',...(opts.headers||{})};
  if(csrfToken&&!['GET','HEAD','OPTIONS'].includes(method))headers['X-CSRF-Token']=csrfToken;
  const r=await fetch(apiUrl(url),{...opts,headers,credentials:'include'});
  let body={}; try{body=await r.json()}catch{}
  if(!r.ok){const e=new Error(body.error||'Request failed');e.status=r.status;e.payload=body;throw e}
  return body;
};
async function refreshCsrf(){
  try{const x=await api('/api/csrf');csrfToken=x.csrf_token||''}catch(e){csrfToken=''}
}
function renderEnvironmentBanner(){
  const b=$('#environmentBanner');if(!b)return;
  const test=Boolean(APP_CONFIG.TEST_SYSTEM)||state.runtime?.test_mode||state.runtime?.environment==='test';
  if(test){b.textContent='🧪 TESTSYSTEM – keine produktiven Daten verwenden';b.classList.remove('hidden')}
  else b.classList.add('hidden');
  const dl=$('#calendarDownloadLink');if(dl)dl.href=apiUrl('/api/calendar.ics');
}
const setStatus=t=>{$('#status').textContent=t;setTimeout(()=>$('#status').textContent='Bereit',1800)};
const eventBy=id=>state.events.find(x=>x.id===id);
const personBy=id=>state.people.find(x=>x.id===id);
const shiftAssignments=id=>state.assignments.filter(a=>a.shift_id===id);

async function load(){
  try{
    state=await api('/api/state');
    await refreshCsrf();renderEnvironmentBanner();
    state.availability=state.availability||[];state.swaps=state.swaps||[];state.notifications=state.notifications||[];state.users=state.users||[];state.settings=state.settings||{min_rest_hours:8,weekly_warning_hours:40};
    hideLogin();applyPermissions();render();renderEnterpriseViews();
  }catch(e){if(e.status===401){showLogin();return}throw e}
}

function coverage(){
  const req=state.shifts.reduce((n,s)=>n+Number(s.required||0),0);
  return req?Math.round(state.assignments.length/req*100):0;
}
function formatDateDE(iso){
  if(!iso)return '';
  const d=new Date(iso+'T12:00:00');
  if(Number.isNaN(d.getTime()))return iso;
  return new Intl.DateTimeFormat('de-CH',{day:'2-digit',month:'2-digit',year:'numeric'}).format(d);
}
function monthDE(iso){
  const d=new Date(iso+'T12:00:00');
  if(Number.isNaN(d.getTime()))return '';
  return new Intl.DateTimeFormat('de-CH',{month:'short'}).format(d).replace('.','').toUpperCase();
}
function todayISO(){
  const d=new Date();
  const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`;
}
function render(){
  applyRoleNavigation();
  $('#sEvents').textContent=state.events.length;
  $('#sShifts').textContent=state.shifts.length;
  $('#sPeople').textContent=state.people.length;
  if($('#sTemplates')) $('#sTemplates').textContent=(state.templates||[]).length;
  $('#sCoverage').textContent=coverage()+'%';
  updateNotificationBadge();
  renderDashboardWarnings();
  renderWorkloadOverview();
  renderDashboardEvents();
  renderDashboardShiftCalendar();
  renderEvents(); renderPeople(); renderShifts(); renderEventSelect(); renderShiftLeaderSelect(); renderTemplateLeaderSelect(); renderTemplateEventSelect(); renderTemplates();
  renderNotificationPreferences(); renderReminderSettings(); renderEmailSettings(); renderSmsSettings(); renderShiftInfoEditor(); renderEventCockpit(); renderReports(); renderPlannerFilters(); renderSkills(); renderAutoPlanEvent(); renderStaffingSuggestions(); renderPlanningSettings(); renderPlannerPeoplePalette(); renderShiftAssignmentBoard(); renderDropBoard(); renderAvailability(); renderWeekPlanner(); renderEventPublishSummary(); renderCloneEvent(); renderEventPool(); renderSignupManagement(); renderEmployeePortal(); renderEmployeeOpenShifts(); renderEmployeeAvailability(); renderEmployeeSignupStatus(); loadCalendarSubscription(); renderAuditLog(); renderCalendarFilters(); renderTimeline();
}
function totalUpcomingHours(personId){return state.assignments.filter(a=>a.person_id===personId).map(a=>state.shifts.find(s=>s.id===a.shift_id)).filter(Boolean).filter(s=>s.date>=todayISO()).reduce((sum,s)=>sum+shiftHours(s),0)}
function renderWorkloadOverview(){const box=$('#workloadOverview');if(!box)return;box.innerHTML='';const rows=state.people.map(p=>({p,h:totalUpcomingHours(p.id)})).sort((a,b)=>b.h-a.h),max=Math.max(1,...rows.map(x=>x.h));if(!rows.length){box.innerHTML='<div class="empty">Noch keine Personen vorhanden.</div>';return}rows.slice(0,12).forEach(({p,h})=>{const r=document.createElement('div');r.className='workload-row';r.innerHTML=`<div class="workload-name">${p.name}</div><div class="workload-bar"><i style="width:${Math.max(2,h/max*100)}%"></i></div><strong>${h.toFixed(1)} h</strong>`;box.appendChild(r)})}
function restConflictForCandidate(personId,shift){const minRest=Number(state.settings?.min_rest_hours||0);if(!minRest)return '';const ts=new Date(`${shift.date}T${shift.start}:00`);let te=new Date(`${shift.date}T${shift.end}:00`);if(te<=ts)te.setDate(te.getDate()+1);for(const a of state.assignments.filter(a=>a.person_id===personId)){const o=state.shifts.find(s=>s.id===a.shift_id);if(!o||o.id===shift.id)continue;const os=new Date(`${o.date}T${o.start}:00`);let oe=new Date(`${o.date}T${o.end}:00`);if(oe<=os)oe.setDate(oe.getDate()+1);if(ts<oe&&os<te)return `Überschneidung: ${o.name}`;const gap=te<=os?(os-te)/3600000:oe<=ts?(ts-oe)/3600000:0;if(gap>=0&&gap<minRest)return `Nur ${gap.toFixed(1)} h Ruhezeit`}return ''}

function personSkillIds(personId){return (state.person_skills||[]).filter(x=>x.person_id===personId).map(x=>x.skill_id)}
function shiftSkillIds(shiftId){return (state.shift_skills||[]).filter(x=>x.shift_id===shiftId).map(x=>x.skill_id)}
function missingSkills(personId,shiftId){
  const owned=new Set(personSkillIds(personId));return shiftSkillIds(shiftId).filter(id=>!owned.has(id))
}
function skillNames(ids){return ids.map(id=>state.skills.find(s=>s.id===id)?.name).filter(Boolean)}
function staffingCandidateScore(person,shift){
  if(shiftAssignments(shift.id).some(a=>a.person_id===person.id))return null;
  const pool=eventPoolPersonIds(shift.event_id);if(pool.length&&!pool.includes(person.id))return {person,score:-200,reason:'Nicht im Event-Team',blocked:true};
  const missing=missingSkills(person.id,shift.id);if(missing.length)return {person,score:-150,reason:'Fehlt: '+skillNames(missing).join(', '),blocked:true};
  const av=personAvailabilityForShift(person.id,shift);if(!av.ok)return {person,score:-100,reason:av.message,blocked:true};
  const rest=restConflictForCandidate(person.id,shift);if(rest)return {person,score:-90,reason:rest,blocked:true};
  const hours=totalUpcomingHours(person.id);let score=100-hours;if(av.status==='preferred')score+=25;if(shiftSkillIds(shift.id).length)score+=15;
  return {person,score,reason:`${av.status==='preferred'?'Bevorzugt · ':''}${hours.toFixed(1)} h geplant${shiftSkillIds(shift.id).length?' · Skills passen':''}`,blocked:false}
}


function renderSkills(){
  const list=$('#skillList'),ps=$('#skillPerson'),ss=$('#skillShift');if(!list||!ps||!ss)return;
  list.innerHTML='';state.skills.forEach(sk=>{const b=document.createElement('button');b.type='button';b.className='skill-pill';b.textContent=sk.name+' ×';b.onclick=()=>remove('skills',sk.id);list.appendChild(b)});
  const pcur=ps.value;ps.innerHTML='';state.people.forEach(p=>{const o=document.createElement('option');o.value=p.id;o.textContent=p.name;ps.appendChild(o)});if([...ps.options].some(o=>o.value===pcur))ps.value=pcur;
  const scur=ss.value;ss.innerHTML='';state.shifts.slice().sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start)).forEach(sh=>{const o=document.createElement('option');o.value=sh.id;o.textContent=`${formatDateDE(sh.date)} · ${sh.name}`;ss.appendChild(o)});if([...ss.options].some(o=>o.value===scur))ss.value=scur;
  renderSkillChecks()
}
function renderSkillChecks(){
  const p=$('#skillPerson')?.value,s=$('#skillShift')?.value,pc=$('#personSkillChecks'),sc=$('#shiftSkillChecks');
  if(pc){const owned=new Set(personSkillIds(p));pc.innerHTML=state.skills.map(x=>`<label><input type="checkbox" value="${x.id}" ${owned.has(x.id)?'checked':''}> ${x.name}</label>`).join('')}
  if(sc){const need=new Set(shiftSkillIds(s));sc.innerHTML=state.skills.map(x=>`<label><input type="checkbox" value="${x.id}" ${need.has(x.id)?'checked':''}> ${x.name}</label>`).join('')}
}
let autoPlanDraft=[];
function renderAutoPlanEvent(){
  const sel=$('#autoPlanEvent');if(!sel)return;const cur=sel.value;sel.innerHTML='';state.events.forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name;sel.appendChild(o)});if([...sel.options].some(o=>o.value===cur))sel.value=cur
}
function buildAutoPlan(){
  const eventId=$('#autoPlanEvent')?.value,box=$('#autoPlanProposal');if(!eventId||!box)return;
  autoPlanDraft=[];const virtualAssigned=new Set(state.assignments.map(a=>`${a.person_id}:${a.shift_id}`));
  const shifts=state.shifts.filter(s=>s.event_id===eventId).sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start));
  shifts.forEach(sh=>{
    let missing=Math.max(0,Number(sh.required||1)-shiftAssignments(sh.id).length);
    const candidates=state.people.map(p=>staffingCandidateScore(p,sh)).filter(x=>x&&!x.blocked).sort((a,b)=>b.score-a.score);
    for(const c of candidates){
      if(!missing)break;if(virtualAssigned.has(`${c.person.id}:${sh.id}`))continue;
      autoPlanDraft.push({shift_id:sh.id,person_id:c.person.id,shift:sh,person:c.person});virtualAssigned.add(`${c.person.id}:${sh.id}`);missing--
    }
  });
  box.innerHTML='';
  if(!autoPlanDraft.length){box.innerHTML='<div class="empty">Keine zusätzlichen Zuweisungen vorgeschlagen.</div>';$('#applyAutoPlan')?.classList.add('hidden');return}
  autoPlanDraft.forEach(x=>{const d=document.createElement('div');d.className='auto-plan-row';d.textContent=`${formatDateDE(x.shift.date)} · ${x.shift.name} → ${x.person.name}`;box.appendChild(d)});
  $('#applyAutoPlan')?.classList.remove('hidden')
}
async function applyAutoPlan(){
  let ok=0,failed=0;
  for(const x of autoPlanDraft){
    try{await api('/api/assignments',{method:'POST',body:JSON.stringify({person_id:x.person_id,shift_id:x.shift_id})});ok++}catch(e){failed++}
  }
  setStatus(`${ok} Zuweisungen übernommen${failed?`, ${failed} übersprungen`:''}`);autoPlanDraft=[];await load()
}

function renderStaffingSuggestions(){const select=$('#suggestionShift'),box=$('#staffingSuggestions');if(!select||!box)return;const cur=select.value;select.innerHTML='';state.shifts.slice().sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start)).forEach(sh=>{const o=document.createElement('option');o.value=sh.id;o.textContent=`${formatDateDE(sh.date)} · ${sh.start} · ${sh.name}`;select.appendChild(o)});if([...select.options].some(o=>o.value===cur))select.value=cur;const sh=state.shifts.find(s=>s.id===select.value);box.innerHTML='';if(!sh)return;state.people.map(p=>staffingCandidateScore(p,sh)).filter(Boolean).sort((a,b)=>b.score-a.score).slice(0,10).forEach(c=>{const row=document.createElement('div');row.className='staffing-candidate '+(c.blocked?'blocked':'');row.innerHTML=`<div><strong>${c.person.name}</strong><span>${c.reason}</span></div>`;const b=document.createElement('button');b.type='button';b.className='secondary small';b.textContent=c.blocked?'Nicht geeignet':'Zuweisen';b.disabled=c.blocked;b.onclick=()=>assignPersonToExistingShift(c.person.id,sh.id);row.appendChild(b);box.appendChild(row)})}
async function renderAuditLog(){const box=$('#auditList');if(!box||userRole()!=='admin')return;try{const data=await api('/api/audit');const q=($('#auditSearch')?.value||'').trim().toLowerCase();const rows=(data.audit_log||[]).filter(x=>!q||`${x.username} ${x.action} ${x.kind} ${x.details}`.toLowerCase().includes(q));box.innerHTML='';if(!rows.length){box.innerHTML='<div class="empty">Keine Audit-Einträge.</div>';return}rows.slice(0,300).forEach(x=>{const d=document.createElement('div');d.className='item audit-row';d.innerHTML=`<div><div class="title">${x.username} · ${x.action}</div><div class="meta">${(x.created_at||'').replace('T',' ')} · ${x.kind}${x.item_id?' · '+x.item_id:''}${x.details?' · '+x.details:''}</div></div>`;box.appendChild(d)})}catch(err){box.innerHTML=`<div class="empty">${err.message}</div>`}}


async function renderEmailStatus(){
  const box=$('#emailStatusBox');if(!box||userRole()!=='admin')return;
  try{const x=await api('/api/email-status');box.innerHTML=`<div class="email-status-counters"><span>✓ ${x.sent} gesendet</span><span>⚠ ${x.failed} fehlgeschlagen</span><span>⏳ ${x.pending} offen</span></div>${x.recent.filter(r=>r.status==='failed').slice(0,3).map(r=>`<div class="meta">${r.to}: ${r.error}</div>`).join('')}`}catch(e){box.textContent=e.message}
}
function renderNotificationPreferences(){
  const f=$('#notificationPreferencesForm');if(!f)return;
  const u=state.current_user||{};
  f.elements.email_notifications.checked=u.email_notifications!==false;
  f.elements.sms_notifications.checked=Boolean(u.sms_notifications);
}
async function renderSmsStatus(){
  const box=$('#smsStatusBox');if(!box||userRole()!=='admin')return;
  try{
    const x=await api('/api/sms-status');
    box.innerHTML=`<div class="email-status-counters"><span>✓ ${x.sent} gesendet</span><span>⚠ ${x.failed} fehlgeschlagen</span><span>⏳ ${x.pending} offen</span></div>${x.recent.filter(r=>r.status==='failed').slice(0,3).map(r=>`<div class="meta">${r.to}: ${r.error}</div>`).join('')}`;
  }catch(e){box.textContent=e.message}
}
function renderSmsSettings(){
  const f=$('#smsSettingsForm');if(!f)return;const x=state.settings||{};
  ['sms_webhook_url','sms_sender'].forEach(k=>{if(f.elements[k])f.elements[k].value=x[k]??''});
  f.elements.sms_enabled.checked=Boolean(x.sms_enabled);renderSmsStatus()
}


async function loadCalendarSubscription(){
  const input=$('#calendarSubscriptionUrl');if(!input||userRole()!=='employee')return;
  try{const x=await api('/api/calendar-subscription');input.value=x.url||x.path||''}catch(e){input.value=''}
}
function renderReminderSettings(){
  const f=$('#reminderSettingsForm');if(!f)return;const x=state.settings||{};
  f.elements.automatic_reminders.checked=x.automatic_reminders!==false;
  f.elements.shift_reminder_days.value=x.shift_reminder_days||'7,1';
  f.elements.availability_reminder_days.value=x.availability_reminder_days||'3,1';
}
function renderEmailSettings(){
  const f=$('#emailSettingsForm');if(!f)return;const x=state.settings||{};
  ['smtp_host','smtp_port','smtp_user','smtp_from'].forEach(k=>{if(f.elements[k])f.elements[k].value=x[k]??''});
  f.elements.smtp_tls.checked=x.smtp_tls!==false;f.elements.email_enabled.checked=Boolean(x.email_enabled);renderEmailStatus()
}
function renderPlanningSettings(){if($('#minRestHours'))$('#minRestHours').value=String(state.settings?.min_rest_hours??8);if($('#weeklyWarningHours'))$('#weeklyWarningHours').value=String(state.settings?.weekly_warning_hours??40)}

function updateNotificationBadge(){const b=$('#notificationBadge');if(!b)return;const n=(state.notifications||[]).filter(x=>x.user_id===state.current_user?.id&&!x.read).length;b.textContent=String(n);b.classList.toggle('hidden',n===0)}
function dashboardPlanningIssues(){const x={understaffed:0,leader:0,conflicts:0,swaps:0};state.shifts.forEach(sh=>{if(shiftAssignments(sh.id).length<Number(sh.required||1))x.understaffed++;if(!sh.leader_person_id)x.leader++;if(typeof planningIssuesForShift==='function')x.conflicts+=planningIssuesForShift(sh).filter(v=>v.includes(':')||v.includes('Überschneidung')).length});x.swaps=(state.swaps||[]).filter(s=>s.status==='pending').length;return x}
function renderDashboardWarnings(){const box=$('#dashboardWarnings');if(!box)return;const w=dashboardPlanningIssues();const items=[['Unterbesetzte Schichten',w.understaffed,'shifts'],['Planungskonflikte',w.conflicts,'weekplanner'],['Ohne Schichtleiter',w.leader,'shifts'],['Offene Tauschanfragen',w.swaps,'swaps']];box.innerHTML='';items.forEach(([l,c,v])=>{const b=document.createElement('button');b.type='button';b.className='dashboard-warning-card '+(c?'warning':'ok');b.innerHTML=`<strong>${c}</strong><span>${l}</span>`;b.onclick=()=>openView(v,l);box.appendChild(b)})}
function renderEmployeeAvailability(){const box=$('#employeeAvailabilityList');if(!box)return;box.innerHTML='';const p=currentEmployeePerson();if(!p)return;const labels={available:'Verfügbar',preferred:'Bevorzugt',unavailable:'Nicht verfügbar',vacation:'Ferien',sick:'Krank'};const rows=(state.availability||[]).filter(a=>a.person_id===p.id).sort((a,b)=>a.date.localeCompare(b.date)).slice(-8);if(!rows.length){box.innerHTML='<div class="empty">Noch keine Verfügbarkeit eingetragen.</div>';return}rows.forEach(a=>{const row=document.createElement('div');row.className='availability-item';row.innerHTML=`<div><strong>${formatDateDE(a.date)}</strong><div class="meta">${labels[a.status]||a.status}${a.start&&a.end?` · ${a.start}–${a.end}`:''}${a.notes?` · ${a.notes}`:''}</div></div>`;const d=document.createElement('button');d.type='button';d.className='danger small';d.textContent='Löschen';d.onclick=()=>remove('availability',a.id);row.appendChild(d);box.appendChild(row)})}


function renderShiftInfoEditor(){
  const sel=$('#shiftInfoShift');if(!sel)return;const cur=sel.value;sel.innerHTML='';
  state.shifts.slice().sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start)).forEach(sh=>{const o=document.createElement('option');o.value=sh.id;o.textContent=`${formatDateDE(sh.date)} · ${sh.name}`;sel.appendChild(o)});
  if([...sel.options].some(o=>o.value===cur))sel.value=cur;loadShiftInfoForm()
}
function loadShiftInfoForm(){
  const form=$('#shiftInfoForm'),sh=state.shifts.find(s=>s.id===$('#shiftInfoShift')?.value);if(!form||!sh)return;
  ['meeting_point','clothing','contact','instructions'].forEach(k=>{if(form.elements[k])form.elements[k].value=sh[k]||''})
}
function renderEventCockpit(){
  const sel=$('#cockpitEvent'),stats=$('#cockpitStats'),issues=$('#cockpitIssues'),shifts=$('#cockpitShifts');if(!sel||!stats||!issues||!shifts)return;
  const cur=sel.value;sel.innerHTML='';state.events.forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name;sel.appendChild(o)});if([...sel.options].some(o=>o.value===cur))sel.value=cur;
  const ev=eventBy(sel.value);if(!ev)return;const ss=state.shifts.filter(s=>s.event_id===ev.id),ids=new Set(ss.map(s=>s.id)),as=state.assignments.filter(a=>ids.has(a.shift_id));
  const required=ss.reduce((n,s)=>n+Number(s.required||1),0),confirmed=as.filter(a=>assignmentConfirmed(a.id)).length,pool=eventPoolPersonIds(ev.id).length;
  stats.innerHTML=`<button class="stat-card"><span>Schichten</span><strong>${ss.length}</strong></button><button class="stat-card"><span>Besetzung</span><strong>${as.length}/${required}</strong></button><button class="stat-card"><span>Bestätigt</span><strong>${confirmed}/${as.length}</strong></button><button class="stat-card"><span>Event-Team</span><strong>${pool||state.people.length}</strong></button>`;
  issues.innerHTML='';const problems=[];
  ss.forEach(sh=>planningIssuesForShift(sh).forEach(x=>problems.push(`${formatDateDE(sh.date)} · ${sh.name}: ${x}`)));
  const pending=(state.signup_requests||[]).filter(x=>x.status==='pending'&&ss.some(s=>s.id===x.shift_id)).length;if(pending)problems.push(`${pending} offene Selbstanmeldung(en)`);
  if(!problems.length)issues.innerHTML='<div class="empty">Keine offenen Planungsprobleme.</div>';else problems.slice(0,30).forEach(x=>{const d=document.createElement('div');d.className='item';d.textContent=x;issues.appendChild(d)});
  shifts.innerHTML='';ss.sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start)).forEach(sh=>{const d=document.createElement('div');d.className='item';const ass=shiftAssignments(sh.id);d.innerHTML=`<div><div class="title">${formatDateDE(sh.date)} · ${sh.start}–${sh.end} · ${sh.name}</div><div class="meta">${ass.length}/${sh.required} besetzt${sh.meeting_point?' · Treffpunkt: '+sh.meeting_point:''}</div></div>`;shifts.appendChild(d)})
}
function reportData(){
  const eventId=$('#reportEvent')?.value,shifts=state.shifts.filter(s=>!eventId||s.event_id===eventId),ids=new Set(shifts.map(s=>s.id));
  return state.people.map(p=>{
    const assignments=state.assignments.filter(a=>a.person_id===p.id&&ids.has(a.shift_id));
    const planned=assignments.reduce((sum,a)=>sum+shiftHours(state.shifts.find(s=>s.id===a.shift_id)),0);
    const actual=assignments.reduce((sum,a)=>sum+(a.actual_hours===''||a.actual_hours==null?shiftHours(state.shifts.find(s=>s.id===a.shift_id)):Number(a.actual_hours)),0);
    const confirmed=assignments.filter(a=>assignmentConfirmed(a.id)).length;
    return {person:p,assignments,planned,actual,confirmed}
  }).filter(x=>x.assignments.length)
}
function renderReports(){
  const sel=$('#reportEvent'),table=$('#reportHoursTable'),summary=$('#reportSummary');if(!sel||!table||!summary)return;
  const cur=sel.value;sel.innerHTML='<option value="">Alle Events</option>';state.events.forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name;sel.appendChild(o)});if([...sel.options].some(o=>o.value===cur))sel.value=cur;
  const rows=reportData(),planned=rows.reduce((s,x)=>s+x.planned,0),actual=rows.reduce((s,x)=>s+x.actual,0),ass=rows.reduce((s,x)=>s+x.assignments.length,0),cnf=rows.reduce((s,x)=>s+x.confirmed,0);
  summary.innerHTML=`<button class="stat-card"><span>Geplant</span><strong>${planned.toFixed(1)} h</strong></button><button class="stat-card"><span>Effektiv</span><strong>${actual.toFixed(1)} h</strong></button><button class="stat-card"><span>Zuweisungen</span><strong>${ass}</strong></button><button class="stat-card"><span>Bestätigt</span><strong>${cnf}/${ass}</strong></button>`;
  table.innerHTML='<div class="report-row report-head"><b>Person</b><b>Geplant</b><b>Effektiv</b><b>Bestätigt</b></div>';
  rows.sort((a,b)=>b.planned-a.planned).forEach(x=>{
    const r=document.createElement('div');r.className='report-row';
    const actualControls=x.assignments.map(a=>{const sh=state.shifts.find(s=>s.id===a.shift_id);return `<label class="actual-hours-entry"><span>${formatDateDE(sh.date)} ${sh.name}</span><input type="number" step="0.25" min="0" data-actual="${a.id}" value="${a.actual_hours??''}" placeholder="${shiftHours(sh).toFixed(2)}"></label>`}).join('');
    r.innerHTML=`<div><strong>${x.person.name}</strong><details><summary>Stunden bearbeiten</summary>${actualControls}</details></div><div>${x.planned.toFixed(1)} h</div><div>${x.actual.toFixed(1)} h</div><div>${x.confirmed}/${x.assignments.length}</div>`;
    table.appendChild(r)
  });
  $$('[data-actual]').forEach(i=>i.onchange=async()=>{try{await api('/api/assignments/'+i.dataset.actual,{method:'PATCH',body:JSON.stringify({actual_hours:i.value})});await load()}catch(err){alert(err.message)}})
}
function downloadReportCsv(){
  const rows=reportData();const out=[['Person','Planned hours','Actual hours','Confirmed','Assignments']];
  rows.forEach(x=>out.push([x.person.name,x.planned.toFixed(2),x.actual.toFixed(2),`${x.confirmed}/${x.assignments.length}`,x.assignments.length]));
  const csv=out.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(';')).join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='event-report.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500)
}

function renderDashboardEvents(){
  const box=$('#dashboardEvents');if(!box)return;box.innerHTML='';
  const today=todayISO();
  const events=[...state.events]
    .sort((a,b)=>(a.start_date||'').localeCompare(b.start_date||''))
    .filter(e=>(e.end_date||e.start_date||'')>=today)
    .slice(0,4);
  const source=events.length?events:[...state.events].sort((a,b)=>(b.start_date||'').localeCompare(a.start_date||'')).slice(0,4);
  if(!source.length){box.innerHTML='<div class="empty">Noch keine Events vorhanden.</div>';return}
  source.forEach(e=>{
    const row=document.createElement('div');row.className='dashboard-event';
    const date=document.createElement('div');date.className='date-tile';
    const day=(e.start_date||'').slice(8,10)||'--';
    date.innerHTML=`<b>${day}</b><span>${monthDE(e.start_date)}<br>${(e.start_date||'').slice(0,4)}</span>`;
    const info=document.createElement('div');
    info.innerHTML=`<div class="event-title"></div><div class="event-meta"></div><div class="event-meta"></div>`;
    info.children[0].textContent=e.name;
    info.children[1].textContent='⌖ '+(e.location||'Kein Ort');
    info.children[2].textContent='▣ '+formatDateDE(e.start_date)+(e.end_date&&e.end_date!==e.start_date?' – '+formatDateDE(e.end_date):'');
    const badge=document.createElement('span');badge.className='event-badge';
    badge.textContent=(e.start_date||'')>today?'Geplant':((e.end_date||e.start_date||'')>=today?'Aktiv':'Beendet');
    row.append(date,info,badge);box.appendChild(row);
  });
}

function renderDashboardShiftCalendar(){
  const box=$('#dashboardShiftCalendar');if(!box)return;box.innerHTML='';
  const today=todayISO();

  if($('#dashboardDate')){
    $('#dashboardDate').textContent=new Intl.DateTimeFormat(
      'de-CH',
      {weekday:'long',day:'2-digit',month:'long',year:'numeric'}
    ).format(new Date());
  }

  let shifts=[...state.shifts]
    .filter(s=>(s.date||'')>=today)
    .sort((a,b)=>(a.date+a.start+a.end).localeCompare(b.date+b.start+b.end));

  if(!shifts.length){
    shifts=[...state.shifts]
      .sort((a,b)=>(b.date+b.start).localeCompare(a.date+a.start))
      .slice(0,8)
      .sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start));
  }

  if(!shifts.length){
    box.innerHTML='<div class="empty">Noch keine geplanten Schichten.</div>';
    return;
  }

  const dates=[...new Set(shifts.map(s=>s.date))].slice(0,3);

  dates.forEach(date=>{
    const dayShifts=shifts.filter(s=>s.date===date).slice(0,5);

    const row=document.createElement('div');
    row.className='dashboard-calendar-day';

    const day=document.createElement('div');
    day.className='dashboard-calendar-date';

    const wd=document.createElement('strong');
    wd.textContent=weekdayDE(date);

    const d=document.createElement('span');
    d.textContent=formatDateDE(date);

    day.append(wd,d);

    const track=document.createElement('div');
    track.className='dashboard-calendar-track';

    dayShifts.forEach(sh=>{
      const ass=shiftAssignments(sh.id);
      const leader=personBy(sh.leader_person_id);

      const card=document.createElement('button');
      card.type='button';
      card.className='dashboard-calendar-shift';
      card.dataset.go='shiftcalendar';

      const time=document.createElement('div');
      time.className='dashboard-calendar-time';
      time.textContent=`${sh.start}–${sh.end}`;

      const name=document.createElement('div');
      name.className='dashboard-calendar-name';
      name.textContent=sh.name;

      const meta=document.createElement('div');
      meta.className='dashboard-calendar-meta';
      meta.textContent=`${ass.length}/${sh.required} Personen`;

      const lead=document.createElement('div');
      lead.className='dashboard-calendar-leader';
      lead.textContent=leader?.name?`Leitung: ${leader.name}`:'Keine Leitung';

      card.append(time,name,meta,lead);
      track.appendChild(card);
    });

    if(shifts.filter(s=>s.date===date).length>dayShifts.length){
      const more=document.createElement('button');
      more.type='button';
      more.className='dashboard-calendar-more';
      more.dataset.go='shiftcalendar';
      more.textContent=`+${shifts.filter(s=>s.date===date).length-dayShifts.length} weitere`;
      track.appendChild(more);
    }

    row.append(day,track);
    box.appendChild(row);
  });

  // data-go buttons are dynamically created, therefore bind them here.
  box.querySelectorAll('[data-go="shiftcalendar"]').forEach(btn=>{
    btn.onclick=()=>openView('shiftcalendar','Schichtkalender');
  });
}

function renderUpcoming(){
  const box=$('#upcoming'); if(!box)return; box.innerHTML='';
  const today=todayISO();
  if($('#dashboardDate')){
    $('#dashboardDate').textContent=new Intl.DateTimeFormat('de-CH',{weekday:'long',day:'2-digit',month:'long',year:'numeric'}).format(new Date());
  }
  let shifts=[...state.shifts].filter(s=>s.date===today).sort((a,b)=>a.start.localeCompare(b.start));
  if(!shifts.length) shifts=[...state.shifts].filter(s=>s.date>=today).sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start)).slice(0,5);
  else shifts=shifts.slice(0,5);
  if(!shifts.length){box.innerHTML='<div class="empty">Noch keine geplanten Schichten.</div>';return}
  shifts.forEach(s=>{
    const ass=shiftAssignments(s.id);
    const row=document.createElement('div');row.className='dashboard-shift';
    const tb=document.createElement('div');tb.className='shift-time-badge';
    tb.textContent=`${s.start} – ${s.end}`;
    const info=document.createElement('div');
    const names=ass.map(a=>personBy(a.person_id)?.name).filter(Boolean);
    info.innerHTML='<div class="shift-title"></div><div class="shift-people"></div>';
    info.children[0].textContent=s.name+(s.role?' · '+s.role:'');
    info.children[1].textContent=names.length?names.join(', '):`${eventBy(s.event_id)?.name||'Event'} · ${formatDateDE(s.date)}`;
    const cov=document.createElement('div');cov.className='coverage-mini';cov.textContent=`👥 ${ass.length} / ${s.required}`;
    row.append(tb,info,cov);box.appendChild(row);
  });
}


function eventEditForm(e){
  const wrap=document.createElement('div');wrap.className='inline-edit-form';
  wrap.innerHTML=`
    <label>Name<input data-field="name"></label>
    <label>Ort<input data-field="location"></label>
    <label>Startdatum<input type="date" data-field="start_date"></label>
    <label>Enddatum<input type="date" data-field="end_date"></label>
    <label>Verfügbarkeit bis<input type="date" data-field="availability_deadline"></label>
    <label><input type="checkbox" data-field="availability_locked"> Verfügbarkeit sperren</label>
    <label class="full">Notizen<textarea data-field="notes" rows="3"></textarea></label>
    <div class="inline-edit-actions full">
      <button type="button" class="primary save-edit">Speichern</button>
      <button type="button" class="secondary cancel-edit">Abbrechen</button>
    </div>`;
  ['name','location','start_date','end_date','availability_deadline','notes'].forEach(k=>{
    const el=wrap.querySelector(`[data-field="${k}"]`); if(el)el.value=e[k]||'';
  });
  const lock=wrap.querySelector('[data-field="availability_locked"]');if(lock)lock.checked=Boolean(e.availability_locked);
  return wrap;
}
function personEditForm(p){
  const wrap=document.createElement('div');wrap.className='inline-edit-form';
  wrap.innerHTML=`
    <label>Name<input data-field="name"></label>
    <label>Rolle<input data-field="role"></label>
    <label>Email<input type="email" data-field="email"></label>
    <label>Telefon<input data-field="phone"></label>
    <label>Max. Stunden / Tag<input type="number" min="0" step="0.5" data-field="max_hours_day"></label>
    <div class="inline-edit-actions full">
      <button type="button" class="primary save-edit">Speichern</button>
      <button type="button" class="secondary cancel-edit">Abbrechen</button>
    </div>`;
  ['name','role','email','phone','max_hours_day'].forEach(k=>{
    const el=wrap.querySelector(`[data-field="${k}"]`); if(el)el.value=p[k]??'';
  });
  return wrap;
}
async function editEventItem(e, card){
  if(!card)return;
  if(card.querySelector('.inline-edit-form'))return;
  const form=eventEditForm(e);
  const body=card.querySelector('.item-top') || card.firstElementChild;
  card.appendChild(form);
  form.querySelector('.cancel-edit').onclick=()=>form.remove();
  form.querySelector('.save-edit').onclick=async()=>{
    const payload={};
    form.querySelectorAll('[data-field]').forEach(el=>payload[el.dataset.field]=el.type==='checkbox'?el.checked:el.value);
    try{
      await api('/api/events/'+e.id,{method:'PATCH',body:JSON.stringify(payload)});
      setStatus('Event updated');
      await load();
    }catch(err){alert(err.message)}
  };
}
async function editPersonItem(p, card){
  if(!card)return;
  if(card.querySelector('.inline-edit-form'))return;
  const form=personEditForm(p);
  card.appendChild(form);
  form.querySelector('.cancel-edit').onclick=()=>form.remove();
  form.querySelector('.save-edit').onclick=async()=>{
    const payload={};
    form.querySelectorAll('[data-field]').forEach(el=>payload[el.dataset.field]=el.value);
    payload.max_hours_day=Number(payload.max_hours_day||0);
    try{
      await api('/api/people/'+p.id,{method:'PATCH',body:JSON.stringify(payload)});
      setStatus('Person updated');
      await load();
    }catch(err){alert(err.message)}
  };
}
async function editShiftItem(s){
  const name=prompt('Schichtname',s.name); if(name===null)return;
  const currentLeader=personBy(s.leader_person_id);
  const leaderName=prompt(
    'Schichtleiter (Name)\n\nVerfügbare Personen:\n'+state.people.map(p=>p.name).join('\n')+'\n\nLeer lassen = kein Schichtleiter',
    currentLeader?.name||''
  );
  if(leaderName===null)return;
  let leader_person_id='';
  if(String(leaderName).trim()){
    const leader=state.people.find(p=>String(p.name||'').trim().toLowerCase()===String(leaderName).trim().toLowerCase());
    if(!leader){alert('Person nicht gefunden');return}
    leader_person_id=leader.id;
  }
  const date=prompt('Datum (YYYY-MM-DD)',s.date); if(date===null)return;
  const start=prompt('Startzeit (HH:MM)',s.start); if(start===null)return;
  const end=prompt('Endzeit (HH:MM)',s.end); if(end===null)return;
  const required=prompt('Benötigte Personen',s.required??1); if(required===null)return;
  const notes=prompt('Notizen',s.notes||''); if(notes===null)return;
  try{
    await api('/api/shifts/'+s.id,{
      method:'PATCH',
      body:JSON.stringify({name,leader_person_id,date,start,end,required:Number(required)||1,notes})
    });
    setStatus('Schicht aktualisiert');await load()
  }catch(err){alert(err.message)}
}
async function editTemplateItem(t){
  const eventOptions=state.events.map(e=>`${e.id} = ${e.name}`).join('\n');
  const currentEvent=eventBy(t.event_id);
  const eventName=prompt(`Event name\n\nAvailable events:\n${state.events.map(e=>e.name).join('\n')}`,currentEvent?.name||'');
  if(eventName===null)return;
  const event=state.events.find(e=>String(e.name).trim().toLowerCase()===String(eventName).trim().toLowerCase());
  if(!event){alert('Event nicht gefunden');return}
  const date=prompt('Datum (YYYY-MM-DD)',t.date||''); if(date===null)return;
  const name=prompt('Vorlagenname',t.name); if(name===null)return;
  const start=prompt('Startzeit (HH:MM)',t.start); if(start===null)return;
  const end=prompt('Endzeit (HH:MM)',t.end); if(end===null)return;
  const required=prompt('Benötigte Personen',t.required??1); if(required===null)return;
  const notes=prompt('Notizen',t.notes||''); if(notes===null)return;
  try{
    await api('/api/templates/'+t.id,{
      method:'PATCH',
      body:JSON.stringify({event_id:event.id,date,name,role,start,end,required:Number(required)||1,notes})
    });
    setStatus('Schichtvorlage aktualisiert');await load()
  }catch(err){alert(err.message)}
}


function eventExpectedPeople(ev){
  const pool=(state.event_people||[]).filter(x=>x.event_id===ev.id).map(x=>x.person_id);
  if(pool.length)return new Set(pool).size;
  const linked=new Set((state.users||[]).filter(u=>u.role==='employee'&&u.active!==false&&u.person_id).map(u=>u.person_id));
  return state.people.filter(p=>linked.has(p.id)).length;
}
function eventAvailabilityResponders(ev){
  return new Set((state.availability||[]).filter(a=>a.date>=ev.start_date&&a.date<=ev.end_date).map(a=>a.person_id)).size;
}
async function sendAvailabilityReminders(eventId){
  try{const x=await api('/api/availability-reminders',{method:'POST',body:JSON.stringify({event_id:eventId})});setStatus(`${x.sent} Erinnerung(en) gesendet`);await load()}catch(e){alert(e.message)}
}
function renderEvents(){
  const box=$('#eventList'); box.innerHTML='';
  if(!state.events.length){box.innerHTML='<div class="empty">No events created.</div>';return}
  state.events.forEach(e=>{
    const d=document.createElement('div'); d.className='item';
    d.innerHTML=`<div class="item-top"><div><div class="title"></div><div class="meta"></div></div><div class="actions"><button class="secondary edit-btn">Edit</button><button class="danger delete-btn">Delete</button></div></div>`;
    d.querySelector('.title').textContent=e.name;
    const expected=eventExpectedPeople(e),responders=eventAvailabilityResponders(e);
    d.querySelector('.meta').textContent=`${e.start_date} → ${e.end_date}${e.location?' · '+e.location:''}${e.availability_deadline?' · Verfügbarkeit bis '+formatDateDE(e.availability_deadline)+` · ${responders}/${expected} abgegeben`:''}${e.availability_locked?' · 🔒 gesperrt':''}`;
    if(e.availability_deadline){const rb=document.createElement('button');rb.className='secondary';rb.textContent='Fehlende erinnern';rb.onclick=()=>sendAvailabilityReminders(e.id);d.querySelector('.actions').prepend(rb)}
    d.querySelector('.edit-btn').onclick=()=>editEventItem(e,d);
    d.querySelector('.delete-btn').onclick=()=>remove('events',e.id);
    box.appendChild(d);
  })
}
function renderPeople(){
  const box=$('#peopleList'); box.innerHTML='';
  if(!state.people.length){box.innerHTML='<div class="empty">No people added.</div>';return}
  const q=String($('#peopleSearch')?.value||'').trim().toLowerCase();
  const list=state.people.filter(p=>{
    if(!q)return true;
    return [p.name,p.email,p.phone].some(v=>String(v||'').toLowerCase().includes(q));
  });
  if(!list.length){
    box.innerHTML='<div class="empty">Keine Personen gefunden.</div>';
    return;
  }
  list.forEach(p=>{
    const d=document.createElement('div'); d.className='item';
    d.innerHTML=`<div class="item-top"><div><div class="title"></div><div class="meta"></div></div><div class="actions"><button class="secondary edit-btn">Edit</button><button class="danger delete-btn">Delete</button></div></div>`;
    d.querySelector('.title').textContent=p.name;
    d.querySelector('.meta').textContent=`${p.role||'No role'}${p.email?' · '+p.email:''}${p.phone?' · '+p.phone:''}`;
    d.querySelector('.edit-btn').onclick=()=>editPersonItem(p,d);
    d.querySelector('.delete-btn').onclick=()=>remove('people',p.id);
    box.appendChild(d);
  })
}


function renderTemplateLeaderSelect(){
  const sel=$('#templateLeader'); if(!sel)return;
  const current=sel.value;
  sel.innerHTML='<option value="">Kein Schichtleiter</option>';
  [...state.people]
    .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'))
    .forEach(p=>{
      const o=document.createElement('option');
      o.value=p.id;
      o.textContent=p.name;
      sel.appendChild(o);
    });
  if([...sel.options].some(o=>o.value===current))sel.value=current;
}

function renderTemplateEventSelect(){
  const sel=$('#templateEvent');if(!sel)return;
  const old=sel.value;
  sel.innerHTML='<option value="">Event wählen…</option>';
  state.events.forEach(e=>{
    const o=document.createElement('option');o.value=e.id;o.textContent=e.name;sel.appendChild(o);
  });
  if([...sel.options].some(o=>o.value===old))sel.value=old;
}


function renderShiftLeaderSelect(){
  const sel=$('#shiftLeader'); if(!sel)return;
  const current=sel.value;
  sel.innerHTML='<option value="">Kein Schichtleiter</option>';
  [...state.people]
    .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'))
    .forEach(p=>{
      const o=document.createElement('option');
      o.value=p.id;
      o.textContent=p.name;
      sel.appendChild(o);
    });
  if([...sel.options].some(o=>o.value===current))sel.value=current;
}

function renderEventSelect(){
  const sel=$('#shiftEvent'), cur=sel.value; sel.innerHTML='<option value="">Select event</option>';
  state.events.forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name;sel.appendChild(o)});
  if([...sel.options].some(o=>o.value===cur)) sel.value=cur;
}
function renderShifts(){
  const box=$('#shiftList'); if(!box)return; box.innerHTML='';
  const shifts=[...state.shifts].sort((a,b)=>(a.date+a.start+a.name).localeCompare(b.date+b.start+b.name));

  if(!shifts.length){
    box.innerHTML='<div class="empty">Noch keine Schichten vorhanden.</div>';
    return;
  }

  shifts.forEach(s=>{
    const card=document.createElement('div');
    card.className='shift-card editable-shift-card';

    const leader=personBy(s.leader_person_id);
    const ev=eventBy(s.event_id);
    const assigned=state.assignments.filter(a=>a.shift_id===s.id);
    const assignedNames=assigned.map(a=>personBy(a.person_id)?.name).filter(Boolean);

    const summary=document.createElement('div');
    summary.className='shift-summary';

    const title=document.createElement('div');
    title.className='title';
    title.textContent=s.name;

    const meta=document.createElement('div');
    meta.className='meta';
    meta.textContent=`${ev?.name||'Unbekanntes Event'} · ${s.date} · ${s.start}–${s.end} · Schichtleiter: ${leader?.name||'Nicht gesetzt'} · ${assigned.length}/${s.required} Personen`;

    const notes=document.createElement('div');
    notes.className='shift-notes';
    notes.textContent=s.notes||'';

    const assignedLine=document.createElement('div');
    assignedLine.className='shift-assigned';
    assignedLine.textContent=assignedNames.length ? `Eingeteilt: ${assignedNames.join(', ')}` : 'Noch niemand eingeteilt';

    const actions=document.createElement('div');
    actions.className='button-row shift-actions';

    const assignBtn=document.createElement('button');
    assignBtn.type='button';
    assignBtn.className='primary';
    assignBtn.textContent='Zuweisen';

    const editBtn=document.createElement('button');
    editBtn.type='button';
    editBtn.className='secondary';
    editBtn.textContent='Bearbeiten';

    const deleteBtn=document.createElement('button');
    deleteBtn.type='button';
    deleteBtn.className='danger';
    deleteBtn.textContent='Löschen';
    deleteBtn.onclick=()=>remove('shifts',s.id);

    actions.append(assignBtn,editBtn,deleteBtn);
    summary.append(title,meta);
    if(s.notes)summary.append(notes);
    summary.append(assignedLine,actions);

    const assignWrap=document.createElement('div');
    assignWrap.className='shift-assign-panel hidden';

    const assignForm=document.createElement('form');
    assignForm.className='shift-assign-form';

    const assignLabel=document.createElement('label');
    assignLabel.textContent='Person auswählen';

    const personSelect=document.createElement('select');
    personSelect.required=true;
    personSelect.name='person_id';

    const emptyPerson=document.createElement('option');
    emptyPerson.value='';
    emptyPerson.textContent='Person wählen…';
    personSelect.appendChild(emptyPerson);

    const assignedIds=new Set(assigned.map(a=>a.person_id));
    [...state.people]
      .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'))
      .forEach(p=>{
        const o=document.createElement('option');
        o.value=p.id;
        o.textContent=p.name+(assignedIds.has(p.id)?' ✓':'');
        personSelect.appendChild(o);
      });

    assignLabel.appendChild(personSelect);

    const assignActions=document.createElement('div');
    assignActions.className='button-row';

    const addPersonBtn=document.createElement('button');
    addPersonBtn.type='submit';
    addPersonBtn.className='primary';
    addPersonBtn.textContent='Person zuweisen';

    const cancelAssignBtn=document.createElement('button');
    cancelAssignBtn.type='button';
    cancelAssignBtn.className='secondary';
    cancelAssignBtn.textContent='Abbrechen';

    assignActions.append(addPersonBtn,cancelAssignBtn);
    assignForm.append(assignLabel,assignActions);
    assignWrap.appendChild(assignForm);

    assignBtn.onclick=()=>{
      assignWrap.classList.toggle('hidden');
      editWrap.classList.add('hidden');
    };

    cancelAssignBtn.onclick=()=>{
      assignWrap.classList.add('hidden');
    };

    assignForm.onsubmit=async e=>{
      e.preventDefault();
      const personId=personSelect.value;
      if(!personId)return;

      if(state.assignments.some(a=>a.shift_id===s.id && a.person_id===personId)){
        alert('Diese Person ist dieser Schicht bereits zugewiesen.');
        return;
      }

      try{
        await api('/api/assignments',{
          method:'POST',
          body:JSON.stringify({shift_id:s.id,person_id:personId})
        });
        setStatus('Person der Schicht zugewiesen');
        await load();
      }catch(err){
        if(err.message==='schedule conflict'){
          if(confirm('Diese Person hat eine überlappende Schicht. Trotzdem zuweisen?')){
            await api('/api/assignments',{
              method:'POST',
              body:JSON.stringify({shift_id:s.id,person_id:personId,force:true})
            });
            setStatus('Person trotz Überschneidung zugewiesen');
            await load();
          }
        }else{
          alert(err.message);
        }
      }
    };

    const editWrap=document.createElement('div');
    editWrap.className='shift-inline-edit hidden';

    const form=document.createElement('form');
    form.className='grid compact-grid shift-edit-form';

    const eventLabel=document.createElement('label');
    eventLabel.textContent='Event';
    const eventSelect=document.createElement('select');
    eventSelect.name='event_id';
    eventSelect.required=true;
    state.events.forEach(e=>{
      const o=document.createElement('option');
      o.value=e.id;
      o.textContent=e.name;
      if(e.id===s.event_id)o.selected=true;
      eventSelect.appendChild(o);
    });
    eventLabel.appendChild(eventSelect);

    const nameLabel=document.createElement('label');
    nameLabel.textContent='Schichtname';
    const nameInput=document.createElement('input');
    nameInput.name='name';
    nameInput.required=true;
    nameInput.value=s.name||'';
    nameLabel.appendChild(nameInput);

    const leaderLabel=document.createElement('label');
    leaderLabel.textContent='Schichtleiter';
    const leaderSelect=document.createElement('select');
    leaderSelect.name='leader_person_id';
    const emptyLeader=document.createElement('option');
    emptyLeader.value='';
    emptyLeader.textContent='Kein Schichtleiter';
    leaderSelect.appendChild(emptyLeader);
    [...state.people]
      .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'))
      .forEach(p=>{
        const o=document.createElement('option');
        o.value=p.id;
        o.textContent=p.name;
        if(p.id===s.leader_person_id)o.selected=true;
        leaderSelect.appendChild(o);
      });
    leaderLabel.appendChild(leaderSelect);

    const dateLabel=document.createElement('label');
    dateLabel.textContent='Datum';
    const dateInput=document.createElement('input');
    dateInput.type='date';
    dateInput.name='date';
    dateInput.required=true;
    dateInput.value=s.date||'';
    dateLabel.appendChild(dateInput);

    const startLabel=document.createElement('label');
    startLabel.textContent='Start';
    const startInput=document.createElement('input');
    startInput.type='time';
    startInput.name='start';
    startInput.required=true;
    startInput.value=s.start||'';
    startLabel.appendChild(startInput);

    const endLabel=document.createElement('label');
    endLabel.textContent='Ende';
    const endInput=document.createElement('input');
    endInput.type='time';
    endInput.name='end';
    endInput.required=true;
    endInput.value=s.end||'';
    endLabel.appendChild(endInput);

    const reqLabel=document.createElement('label');
    reqLabel.textContent='Benötigte Personen';
    const reqInput=document.createElement('input');
    reqInput.type='number';
    reqInput.name='required';
    reqInput.min='1';
    reqInput.max='100';
    reqInput.required=true;
    reqInput.value=String(s.required??1);
    reqLabel.appendChild(reqInput);

    const notesLabel=document.createElement('label');
    notesLabel.textContent='Notizen';
    const notesInput=document.createElement('input');
    notesInput.name='notes';
    notesInput.value=s.notes||'';
    notesLabel.appendChild(notesInput);

    const formActions=document.createElement('div');
    formActions.className='button-row wide';

    const saveBtn=document.createElement('button');
    saveBtn.type='submit';
    saveBtn.className='primary';
    saveBtn.textContent='Speichern';

    const cancelBtn=document.createElement('button');
    cancelBtn.type='button';
    cancelBtn.className='secondary';
    cancelBtn.textContent='Abbrechen';

    formActions.append(saveBtn,cancelBtn);
    form.append(eventLabel,nameLabel,leaderLabel,dateLabel,startLabel,endLabel,reqLabel,notesLabel,formActions);
    editWrap.appendChild(form);

    editBtn.onclick=()=>{
      assignWrap.classList.add('hidden');
      summary.classList.add('hidden');
      editWrap.classList.remove('hidden');
    };

    cancelBtn.onclick=()=>{
      editWrap.classList.add('hidden');
      summary.classList.remove('hidden');
    };

    form.onsubmit=async e=>{
      e.preventDefault();
      const payload=formJSON(form);
      payload.required=Number(payload.required)||1;

      try{
        await api('/api/shifts/'+s.id,{
          method:'PATCH',
          body:JSON.stringify(payload)
        });
        setStatus('Schicht aktualisiert');
        await load();
      }catch(err){
        alert(err.message);
      }
    };

    card.append(summary,assignWrap,editWrap);
    box.appendChild(card);
  });
}

function renderTemplates(){
  const box=$('#templateList'); if(!box)return; box.innerHTML='';
  const templates=[...(state.templates||[])];

  if(!templates.length){
    box.innerHTML='<div class="empty">Noch keine Schichtvorlagen.</div>';
    renderTemplateMirror();
    return;
  }

  templates.forEach(t=>{
    const card=document.createElement('div');
    card.className='shift-card editable-template-card';
    card.draggable=true;

    const ev=eventBy(t.event_id);
    const leader=personBy(t.leader_person_id);

    const summary=document.createElement('div');
    summary.className='template-summary';

    const title=document.createElement('div');
    title.className='title';
    title.textContent=t.name;

    const meta=document.createElement('div');
    meta.className='meta';
    meta.textContent=`${ev?.name||'Kein Event'} · ${t.date||'Kein Datum'} · ${t.start}–${t.end} · Schichtleiter: ${leader?.name||'Nicht gesetzt'} · ${t.required} Personen`;

    const notes=document.createElement('div');
    notes.className='shift-notes';
    notes.textContent=t.notes||'';

    const actions=document.createElement('div');
    actions.className='button-row shift-actions';

    const createBtn=document.createElement('button');
    createBtn.type='button';
    createBtn.className='primary';
    createBtn.textContent='Schicht erstellen';
    createBtn.onclick=()=>createShiftFromTemplate(t);

    const editBtn=document.createElement('button');
    editBtn.type='button';
    editBtn.className='secondary';
    editBtn.textContent='Bearbeiten';

    const deleteBtn=document.createElement('button');
    deleteBtn.type='button';
    deleteBtn.className='danger';
    deleteBtn.textContent='Löschen';
    deleteBtn.onclick=()=>remove('templates',t.id);

    actions.append(createBtn,editBtn,deleteBtn);
    summary.append(title,meta);
    if(t.notes)summary.append(notes);
    summary.append(actions);

    const editWrap=document.createElement('div');
    editWrap.className='template-inline-edit hidden';

    const form=document.createElement('form');
    form.className='grid compact-grid template-edit-form';

    const eventLabel=document.createElement('label');
    eventLabel.textContent='Event';
    const eventSelect=document.createElement('select');
    eventSelect.name='event_id';
    eventSelect.required=true;
    state.events.forEach(e=>{
      const o=document.createElement('option');
      o.value=e.id;
      o.textContent=e.name;
      if(e.id===t.event_id)o.selected=true;
      eventSelect.appendChild(o);
    });
    eventLabel.appendChild(eventSelect);

    const dateLabel=document.createElement('label');
    dateLabel.textContent='Datum';
    const dateInput=document.createElement('input');
    dateInput.type='date';
    dateInput.name='date';
    dateInput.required=true;
    dateInput.value=t.date||'';
    dateLabel.appendChild(dateInput);

    const nameLabel=document.createElement('label');
    nameLabel.textContent='Name';
    const nameInput=document.createElement('input');
    nameInput.name='name';
    nameInput.required=true;
    nameInput.value=t.name||'';
    nameLabel.appendChild(nameInput);

    const leaderLabel=document.createElement('label');
    leaderLabel.textContent='Schichtleiter';
    const leaderSelect=document.createElement('select');
    leaderSelect.name='leader_person_id';
    const empty=document.createElement('option');
    empty.value='';
    empty.textContent='Kein Schichtleiter';
    leaderSelect.appendChild(empty);

    [...state.people]
      .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'))
      .forEach(p=>{
        const o=document.createElement('option');
        o.value=p.id;
        o.textContent=p.name;
        if(p.id===t.leader_person_id)o.selected=true;
        leaderSelect.appendChild(o);
      });
    leaderLabel.appendChild(leaderSelect);

    const startLabel=document.createElement('label');
    startLabel.textContent='Start';
    const startInput=document.createElement('input');
    startInput.type='time';
    startInput.name='start';
    startInput.required=true;
    startInput.value=t.start||'';
    startLabel.appendChild(startInput);

    const endLabel=document.createElement('label');
    endLabel.textContent='Ende';
    const endInput=document.createElement('input');
    endInput.type='time';
    endInput.name='end';
    endInput.required=true;
    endInput.value=t.end||'';
    endLabel.appendChild(endInput);

    const reqLabel=document.createElement('label');
    reqLabel.textContent='Benötigte Personen';
    const reqInput=document.createElement('input');
    reqInput.type='number';
    reqInput.name='required';
    reqInput.min='1';
    reqInput.max='100';
    reqInput.required=true;
    reqInput.value=String(t.required??1);
    reqLabel.appendChild(reqInput);

    const notesLabel=document.createElement('label');
    notesLabel.textContent='Notizen';
    const notesInput=document.createElement('input');
    notesInput.name='notes';
    notesInput.value=t.notes||'';
    notesLabel.appendChild(notesInput);

    const formActions=document.createElement('div');
    formActions.className='button-row wide';

    const saveBtn=document.createElement('button');
    saveBtn.type='submit';
    saveBtn.className='primary';
    saveBtn.textContent='Speichern';

    const cancelBtn=document.createElement('button');
    cancelBtn.type='button';
    cancelBtn.className='secondary';
    cancelBtn.textContent='Abbrechen';

    formActions.append(saveBtn,cancelBtn);
    form.append(eventLabel,dateLabel,nameLabel,leaderLabel,startLabel,endLabel,reqLabel,notesLabel,formActions);
    editWrap.appendChild(form);

    editBtn.onclick=()=>{
      summary.classList.add('hidden');
      editWrap.classList.remove('hidden');
      card.draggable=false;
    };

    cancelBtn.onclick=()=>{
      editWrap.classList.add('hidden');
      summary.classList.remove('hidden');
      card.draggable=true;
    };

    form.onsubmit=async e=>{
      e.preventDefault();
      const payload=formJSON(form);
      payload.required=Number(payload.required)||1;
      try{
        await api('/api/templates/'+t.id,{
          method:'PATCH',
          body:JSON.stringify(payload)
        });
        setStatus('Schichtvorlage aktualisiert');
        await load();
      }catch(err){
        alert(err.message);
      }
    };

    card.addEventListener('dragstart',e=>{
      if(card.draggable){
        e.dataTransfer.setData('text/plain',t.id);
        e.dataTransfer.effectAllowed='copy';
      }
    });

    card.append(summary,editWrap);
    box.appendChild(card);
  });

  renderTemplateMirror();
}

function renderTemplateMirror(){
  const box=$('#templateListMirror');if(!box)return;box.innerHTML='';
  const templates=state.templates||[];
  if(!templates.length){box.innerHTML='<div class="empty">Noch keine Schichtvorlagen.</div>';return}
  templates.forEach(t=>{
    const d=document.createElement('div');d.className='shift-template';d.draggable=true;
    d.innerHTML='<div class="title"></div><div class="meta"></div>';
    d.querySelector('.title').textContent=t.name+(t.role?' — '+t.role:'');
    const ev=eventBy(t.event_id);const leader=personBy(t.leader_person_id);d.querySelector('.meta').textContent=`${ev?.name||'Kein Event'} · ${t.date||'Kein Datum'} · ${t.start}–${t.end} · Schichtleiter: ${leader?.name||'Nicht gesetzt'} · ${t.required} Personen`;
    d.addEventListener('dragstart',e=>{e.dataTransfer.setData('text/plain',t.id);e.dataTransfer.effectAllowed='copy'});
    box.appendChild(d);
  });
}
function renderPlannerFilters(){
  const es=$('#plannerEvent'), ds=$('#plannerDate'), ps=$('#plannerPerson'); if(!es||!ds)return;
  const oldE=es.value, oldD=ds.value, oldP=ps?.value||'';
  es.innerHTML='<option value="">Alle Events</option>';
  state.events.forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name;es.appendChild(o)});
  if([...es.options].some(o=>o.value===oldE))es.value=oldE;

  const dates=[...new Set(state.shifts.filter(s=>!es.value||s.event_id===es.value).map(s=>s.date))].sort();
  ds.innerHTML='<option value="">Alle Tage</option>';
  dates.forEach(x=>{const o=document.createElement('option');o.value=x;o.textContent=x;ds.appendChild(o)});
  if([...ds.options].some(o=>o.value===oldD))ds.value=oldD;

  if(ps){
    ps.innerHTML='<option value="">Alle Personen</option>';
    state.people.forEach(p=>{const o=document.createElement('option');o.value=p.id;o.textContent=p.name;ps.appendChild(o)});
    if([...ps.options].some(o=>o.value===oldP))ps.value=oldP;
  }
}


function filteredPlannerPeople(){
  const pid=$('#plannerPerson')?.value||'';
  return pid ? state.people.filter(p=>p.id===pid) : [...state.people];
}
function filteredPlannerShifts(){
  const e=$('#plannerEvent')?.value||'', d=$('#plannerDate')?.value||'';
  return [...state.shifts].filter(s=>(!e||s.event_id===e)&&(!d||s.date===d))
    .sort((a,b)=>(a.date+a.start+a.name).localeCompare(b.date+b.start+b.name));
}


function refreshPlannerBoards(){
  renderPlannerFilters();
  renderPlannerPeoplePalette();
  renderShiftAssignmentBoard();
  renderDropBoard();
}

function selectedPlannerEvent(){return $('#plannerEvent')?.value||(state.events[0]?.id||'')}
function selectedPlannerDate(eventId){return $('#plannerDate')?.value||eventBy(eventId)?.start_date||''}


function plannerPersonAvailability(personId,date){
  return (state.availability||[]).find(a=>a.person_id===personId&&a.date===date);
}

function renderPlannerPeoplePalette(){
  const box=$('#plannerPeoplePalette');if(!box)return;box.innerHTML='';

  const people=filteredPlannerPeople()
    .slice()
    .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'));

  if(!people.length){
    box.innerHTML='<div class="empty">Keine Personen für den gewählten Filter.</div>';
    return;
  }

  const date=$('#plannerDate')?.value||'';

  people.forEach(p=>{
    const card=document.createElement('div');
    card.className='planner-person-module';
    card.draggable=isManager();
    card.dataset.personId=p.id;

    const name=document.createElement('div');
    name.className='planner-person-module-name';
    name.textContent=p.name;

    const meta=document.createElement('div');
    meta.className='mini';

    if(date){
      const hours=hoursForPersonOnDate(p.id,date);
      const av=plannerPersonAvailability(p.id,date);
      let avText='';
      if(av?.status==='unavailable')avText=' · Nicht verfügbar';
      else if(av?.status==='preferred')avText=' · Bevorzugt';
      else if(av?.status==='available')avText=' · Verfügbar';
      meta.textContent=`${hours.toFixed(1)} h geplant${avText}`;
      if(av?.status==='unavailable')card.classList.add('person-unavailable');
      if(av?.status==='preferred')card.classList.add('person-preferred');
    }else{
      const count=state.assignments.filter(a=>a.person_id===p.id).length;
      meta.textContent=`${count} Zuweisung${count===1?'':'en'}`;
    }

    card.append(name,meta);

    card.addEventListener('dragstart',e=>{
      if(!isManager()){e.preventDefault();return}
      e.dataTransfer.setData('application/x-planner-person',p.id);
      e.dataTransfer.setData('text/plain','person:'+p.id);
      e.dataTransfer.effectAllowed='copy';
      card.classList.add('dragging-person');
    });
    card.addEventListener('dragend',()=>card.classList.remove('dragging-person'));

    box.appendChild(card);
  });
}

async function assignPersonToExistingShift(personId,shiftId){
  const person=personBy(personId);
  const shift=state.shifts.find(s=>s.id===shiftId);
  if(!person||!shift)return;

  if(state.assignments.some(a=>a.person_id===personId&&a.shift_id===shiftId)){
    alert(`${person.name} ist dieser Schicht bereits zugewiesen.`);
    return;
  }

  try{
    await api('/api/assignments',{
      method:'POST',
      body:JSON.stringify({person_id:personId,shift_id:shiftId})
    });
    setStatus(`${person.name} → ${shift.name}`);
    await load();
  }catch(err){
    if(err.status===409&&err.message==='schedule conflict'){
      const details=(err.payload?.conflicts||[]).join('\n• ');
      const msg=`Konflikt bei ${person.name}:\n\n${details?'• '+details+'\n\n':''}Trotzdem dieser Schicht zuweisen?`;
      if(confirm(msg)){
        await api('/api/assignments',{
          method:'POST',
          body:JSON.stringify({person_id:personId,shift_id:shiftId,force:true})
        });
        setStatus(`${person.name} trotz Warnung zugewiesen`);
        await load();
      }
      return;
    }
    if(err.status===409){
      alert(err.message);
      return;
    }
    alert(err.message);
  }
}

function renderShiftAssignmentBoard(){
  const box=$('#shiftAssignmentBoard');if(!box)return;box.innerHTML='';

  const shifts=filteredPlannerShifts();

  if(!shifts.length){
    box.innerHTML='<div class="empty">Keine Schichten für den gewählten Filter. Erstelle zuerst eine Schicht oder ändere Event/Tag.</div>';
    return;
  }

  const dates=[...new Set(shifts.map(s=>s.date))].sort();

  dates.forEach(date=>{
    const group=document.createElement('div');
    group.className='shift-plan-date-group';

    const dateHead=document.createElement('div');
    dateHead.className='shift-plan-date';
    dateHead.textContent=formatDateDE(date);
    group.appendChild(dateHead);

    shifts.filter(s=>s.date===date).forEach(sh=>{
      const ass=shiftAssignments(sh.id);
      const leader=personBy(sh.leader_person_id);

      const card=document.createElement('div');
      card.className='shift-drop-card';
      card.dataset.shiftId=sh.id;

      const head=document.createElement('div');
      head.className='shift-drop-card-head';

      const info=document.createElement('div');
      const title=document.createElement('div');
      title.className='title';
      title.textContent=sh.name;

      const meta=document.createElement('div');
      meta.className='meta';
      meta.textContent=`${sh.start}–${sh.end} · Schichtleiter: ${leader?.name||'Nicht gesetzt'}`;

      info.append(title,meta);

      const coverage=document.createElement('span');
      coverage.className='coverage-pill '+(ass.length>=Number(sh.required||1)?'good':'bad');
      coverage.textContent=`${ass.length}/${sh.required}`;

      head.append(info,coverage);

      const people=document.createElement('div');
      people.className='shift-drop-assignees';

      if(!ass.length){
        const hint=document.createElement('div');
        hint.className='shift-drop-empty';
        hint.textContent='Person hier ablegen';
        people.appendChild(hint);
      }else{
        ass.forEach(a=>{
          const p=personBy(a.person_id);if(!p)return;

          const chip=document.createElement('div');
          chip.className='shift-assignee-chip';

          const personName=document.createElement('span');
          personName.textContent=p.name;

          const removeBtn=document.createElement('button');
          removeBtn.type='button';
          removeBtn.title='Zuweisung entfernen';
          removeBtn.textContent='×';
          removeBtn.onclick=async e=>{
            e.stopPropagation();
            if(!isManager())return;
            await remove('assignments',a.id);
          };

          chip.append(personName,removeBtn);
          people.appendChild(chip);
        });
      }

      const footer=document.createElement('div');
      footer.className='shift-drop-footer';
      footer.textContent=sh.notes||'Person aus der linken Liste hierher ziehen';

      card.append(head,people,footer);

      card.addEventListener('dragover',e=>{
        const pid=e.dataTransfer.types.includes('application/x-planner-person');
        if(!pid)return;
        e.preventDefault();
        e.dataTransfer.dropEffect='copy';
        card.classList.add('drag-over');
      });

      card.addEventListener('dragleave',()=>card.classList.remove('drag-over'));

      card.addEventListener('drop',async e=>{
        e.preventDefault();
        card.classList.remove('drag-over');
        if(!isManager())return;

        let personId=e.dataTransfer.getData('application/x-planner-person');
        if(!personId){
          const raw=e.dataTransfer.getData('text/plain');
          if(raw.startsWith('person:'))personId=raw.slice(7);
        }
        if(personId)await assignPersonToExistingShift(personId,sh.id);
      });

      group.appendChild(card);
    });

    box.appendChild(group);
  });
}

function renderDropBoard(){
  const box=$('#dropBoard');if(!box)return;box.innerHTML='';
  if(!state.people.length){box.innerHTML='<div class="empty">Add people first.</div>';return}
  const shifts=filteredPlannerShifts(), ids=new Set(shifts.map(s=>s.id));
  state.people.forEach(p=>{
    const zone=document.createElement('div');zone.className='person-drop';
    const head=document.createElement('div');head.className='person-head';
    const who=document.createElement('div');who.innerHTML='<div class="title"></div><div class="mini"></div>';
    who.querySelector('.title').textContent=p.name;who.querySelector('.mini').textContent=p.role||'No role';
    const ass=state.assignments.filter(a=>a.person_id===p.id&&ids.has(a.shift_id));
    const count=document.createElement('div');count.className='mini';count.textContent=`${ass.length} shift${ass.length===1?'':'s'}`;head.append(who,count);
    const cards=document.createElement('div');cards.className='person-shifts';
    ass.forEach(a=>{
      const sh=state.shifts.find(x=>x.id===a.shift_id);if(!sh)return;
      const c=document.createElement('div');c.className='assigned-card';
      const txt=document.createElement('span');txt.textContent=`${sh.name} · ${sh.date} ${sh.start}–${sh.end}`;
      const rm=document.createElement('button');rm.type='button';rm.textContent='×';rm.onclick=()=>remove('assignments',a.id);c.append(txt,rm);cards.appendChild(c);
    });
    if(!ass.length){const n=document.createElement('span');n.className='mini';n.textContent='Drop a predefined shift here';cards.appendChild(n)}
    zone.addEventListener('dragover',e=>{e.preventDefault();zone.classList.add('drag-over');e.dataTransfer.dropEffect='copy'});
    zone.addEventListener('dragleave',()=>zone.classList.remove('drag-over'));
    zone.addEventListener('drop',async e=>{e.preventDefault();zone.classList.remove('drag-over');const tid=e.dataTransfer.getData('text/plain');const t=(state.templates||[]).find(x=>x.id===tid);if(t)await createAndAssignTemplate(t,p.id)});
    zone.append(head,cards);box.appendChild(zone);
  });
}

function shiftForTemplate(t){
  return state.shifts.find(s=>
    s.event_id===t.event_id &&
    s.date===t.date &&
    String(s.name||'').trim().toLowerCase()===String(t.name||'').trim().toLowerCase() &&
    s.start===t.start &&
    s.end===t.end
  );
}

async function createAndAssignTemplate(t,personId){
  const eventId=t.event_id,date=t.date;
  if(!eventId){alert('Diese Schichtvorlage ist noch keinem Event zugeordnet.');return}
  if(!date){alert('Diese Schichtvorlage hat noch kein Datum.');return}

  try{
    let shift=shiftForTemplate(t);

    if(!shift){
      shift=await api('/api/shifts',{
        method:'POST',
        body:JSON.stringify({
          event_id:eventId,
          leader_person_id:t.leader_person_id||'',
          name:t.name,
          role:t.role,
          date,
          start:t.start,
          end:t.end,
          required:t.required,
          notes:t.notes
        })
      });
    }

    const alreadyAssigned=state.assignments.some(a=>a.shift_id===shift.id && a.person_id===personId);
    if(alreadyAssigned){
      setStatus('Person bereits zugewiesen');
      return;
    }

    try{
      await api('/api/assignments',{
        method:'POST',
        body:JSON.stringify({person_id:personId,shift_id:shift.id})
      });
    }catch(err){
      if(err.message==='schedule conflict'){
        if(confirm('Diese Person hat eine überlappende Schicht. Trotzdem zuweisen?')){
          await api('/api/assignments',{
            method:'POST',
            body:JSON.stringify({person_id:personId,shift_id:shift.id,force:true})
          });
        }else{
          return;
        }
      }else{
        throw err;
      }
    }

    setStatus('Person derselben Schicht zugewiesen');
    await load();
  }catch(err){
    alert(err.message);
  }
}
function minutes(t){if(!t||!t.includes(':'))return 0;const [h,m]=t.split(':').map(Number);return h*60+m}
function roleColorIndex(role){
  const r=(role||'').trim().toLowerCase();
  let h=0;for(let i=0;i<r.length;i++)h=(h*31+r.charCodeAt(i))>>>0;
  return h%6;
}
function roleClass(role){return 'role-c'+roleColorIndex(role)}
function durationMinutes(start,end){
  let s=minutes(start),e=minutes(end);if(e<=s)e+=1440;return Math.max(0,e-s)
}
function formatDuration(mins){
  const h=Math.floor(mins/60),m=mins%60;
  return m?`${h}h ${m}m`:`${h}h`;
}
function snap15(v){return Math.max(0,Math.min(1440,Math.round(v/15)*15))}
function toTime(mins){
  mins=Math.max(0,Math.min(1439,Math.round(mins)));
  const h=Math.floor(mins/60),m=mins%60;return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')
}
function renderRoleLegend(shifts){
  const box=$('#roleLegend');if(!box)return;box.innerHTML='';
  const roles=[...new Set(shifts.map(s=>(s.role||'No role').trim()||'No role'))];
  roles.forEach(role=>{
    const item=document.createElement('div');item.className='legend-item';
    const dot=document.createElement('span');dot.className='legend-dot '+roleClass(role);
    const txt=document.createElement('span');txt.textContent=role;item.append(dot,txt);box.appendChild(item);
  });
}
async function patchShift(shiftId, body){
  return api('/api/shifts/'+shiftId,{method:'PATCH',body:JSON.stringify(body)})
}
async function moveAssignment(assignmentId, personId, force=false){
  return api('/api/assignments/'+assignmentId,{method:'PATCH',body:JSON.stringify({person_id:personId,force})})
}
function personDayMinutes(personId, dayShifts){
  const ids=new Set(dayShifts.map(s=>s.id));
  return state.assignments.filter(a=>a.person_id===personId&&ids.has(a.shift_id))
    .map(a=>state.shifts.find(s=>s.id===a.shift_id)).filter(Boolean)
    .reduce((sum,s)=>sum+durationMinutes(s.start,s.end),0)
}
function makeShiftInteractive(bar, shift, assignment, track, personId){
  let mode=null,startX=0,origStart=0,origEnd=0,trackRect=null;
  const left=document.createElement('span');left.className='resize-handle left';
  const right=document.createElement('span');right.className='resize-handle right';
  bar.append(left,right);

  function pointerDown(e,which){
    e.preventDefault();e.stopPropagation();
    mode=which;startX=e.clientX;origStart=minutes(shift.start);origEnd=minutes(shift.end);if(origEnd<=origStart)origEnd=1440;trackRect=track.getBoundingClientRect();
    bar.setPointerCapture?.(e.pointerId);bar.classList.add('dragging');
  }
  left.addEventListener('pointerdown',e=>pointerDown(e,'resize-left'));
  right.addEventListener('pointerdown',e=>pointerDown(e,'resize-right'));
  bar.addEventListener('pointerdown',e=>{
    if(e.target===left||e.target===right)return;
    pointerDown(e,'move-time');
  });
  bar.addEventListener('pointermove',e=>{
    if(!mode||!trackRect)return;
    const delta=(e.clientX-startX)/trackRect.width*1440;
    let ns=origStart,ne=origEnd;
    if(mode==='move-time'){
      const dur=origEnd-origStart;ns=snap15(origStart+delta);ns=Math.min(ns,1440-dur);ne=ns+dur;
    }else if(mode==='resize-left'){
      ns=snap15(origStart+delta);ns=Math.min(ns,origEnd-15);
    }else{
      ne=snap15(origEnd+delta);ne=Math.max(ne,origStart+15);ne=Math.min(ne,1440);
    }
    bar.style.left=(ns/1440*100)+'%';bar.style.width=((ne-ns)/1440*100)+'%';
    const sp=bar.querySelector('span.time-text');if(sp)sp.textContent=`${toTime(ns)}–${toTime(ne===1440?1439:ne)}`;
    bar.dataset.previewStart=String(ns);bar.dataset.previewEnd=String(ne);
  });
  bar.addEventListener('pointerup',async e=>{
    if(!mode)return;
    const ns=Number(bar.dataset.previewStart??origStart),ne=Number(bar.dataset.previewEnd??origEnd);
    mode=null;bar.classList.remove('dragging');delete bar.dataset.previewStart;delete bar.dataset.previewEnd;
    if(ns===origStart&&ne===origEnd)return;
    try{
      await patchShift(shift.id,{start:toTime(ns),end:toTime(ne===1440?1439:ne)});
      setStatus('Shift time updated');await load();
    }catch(err){alert(err.message);await load()}
  });

  bar.draggable=true;
  bar.addEventListener('dragstart',e=>{
    if(mode){e.preventDefault();return}
    e.dataTransfer.setData('application/x-existing-assignment',JSON.stringify({assignmentId:assignment.id,shiftId:shift.id,fromPerson:personId}));
    e.dataTransfer.effectAllowed='move';
  });
}


function mondayOf(iso){
  const d=iso?new Date(iso+'T12:00:00'):new Date();
  const day=d.getDay()||7;
  d.setDate(d.getDate()-day+1);
  return d.toISOString().slice(0,10);
}

function addDaysISO(iso,n){
  const d=new Date(iso+'T12:00:00');
  d.setDate(d.getDate()+n);
  return d.toISOString().slice(0,10);
}

function shiftHours(sh){
  const [shh,smm]=(sh.start||'00:00').split(':').map(Number);
  const [ehh,emm]=(sh.end||'00:00').split(':').map(Number);
  let mins=(ehh*60+emm)-(shh*60+smm);
  if(mins<0)mins+=24*60;
  return mins/60;
}

function personAvailabilityForShift(personId,sh){
  const rows=(state.availability||[]).filter(a=>a.person_id===personId&&a.date===sh.date);
  if(!rows.length)return {ok:true,status:'unknown',message:''};

  const unavailable=rows.find(a=>['unavailable','vacation','sick'].includes(a.status));
  if(unavailable){
    return {ok:false,status:unavailable.status,message:unavailable.status==='vacation'?'Ferien':unavailable.status==='sick'?'Krank':'Nicht verfügbar'};
  }

  const windowed=rows.filter(a=>a.start&&a.end&&['available','preferred'].includes(a.status));
  if(windowed.length){
    const ok=windowed.some(a=>(sh.start>=a.start && sh.end<=a.end) || (sh.end<sh.start && sh.start>=a.start));
    if(!ok)return {ok:false,status:'outside-window',message:'Ausserhalb Verfügbarkeit'};
  }

  const preferred=rows.find(a=>a.status==='preferred');
  return {ok:true,status:preferred?'preferred':'available',message:preferred?'Bevorzugt':'Verfügbar'};
}

function weeklyHoursForPerson(personId,weekStart){
  const end=addDaysISO(weekStart,6);
  return state.assignments
    .filter(a=>a.person_id===personId)
    .map(a=>state.shifts.find(s=>s.id===a.shift_id))
    .filter(Boolean)
    .filter(s=>s.date>=weekStart&&s.date<=end)
    .reduce((sum,s)=>sum+shiftHours(s),0);
}

function planningIssuesForShift(sh){
  const issues=[];
  const ass=shiftAssignments(sh.id);
  const required=Number(sh.required||1);

  if(ass.length<required)issues.push(`${required-ass.length} Person${required-ass.length===1?'':'en'} fehlen`);
  if(!sh.leader_person_id)issues.push('Schichtleiter fehlt');

  ass.forEach(a=>{
    const p=personBy(a.person_id);if(!p)return;
    const av=personAvailabilityForShift(p.id,sh);
    if(!av.ok)issues.push(`${p.name}: ${av.message}`);
    const restIssue=restConflictForCandidate(p.id,sh);if(restIssue)issues.push(`${p.name}: ${restIssue}`);

    const sameDay=state.assignments
      .filter(x=>x.person_id===p.id&&x.shift_id!==sh.id)
      .map(x=>state.shifts.find(s=>s.id===x.shift_id))
      .filter(Boolean)
      .filter(s=>s.date===sh.date);

    sameDay.forEach(other=>{
      const overlaps=(sh.start<other.end&&other.start<sh.end) || (sh.end<sh.start) || (other.end<other.start);
      if(overlaps)issues.push(`${p.name}: Überschneidung mit ${other.name}`);
    });

    const dailyHours=state.assignments
      .filter(x=>x.person_id===p.id)
      .map(x=>state.shifts.find(s=>s.id===x.shift_id))
      .filter(Boolean)
      .filter(s=>s.date===sh.date)
      .reduce((sum,s)=>sum+shiftHours(s),0);

    const max=Number(p.max_hours_day||p.max_hours||0);
    if(max && dailyHours>max)issues.push(`${p.name}: ${dailyHours.toFixed(1)} h / max. ${max} h`);
  });

  return [...new Set(issues)];
}


function eventStatus(ev){
  return ev?.status||'draft';
}

async function setEventStatus(eventId,status){
  try{
    await api('/api/events/'+eventId,{method:'PATCH',body:JSON.stringify({status})});
    setStatus(status==='published'?'Event veröffentlicht':'Event auf Entwurf gesetzt');
    await load();
  }catch(err){alert(err.message)}
}

function renderEventPublishSummary(){
  const box=$('#eventPublishSummary');if(!box)return;box.innerHTML='';
  const events=state.events.slice().sort((a,b)=>(b.start_date||'').localeCompare(a.start_date||''));

  if(!events.length){
    box.innerHTML='<div class="empty">Noch keine Events vorhanden.</div>';return;
  }

  events.forEach(ev=>{
    const row=document.createElement('div');row.className='publish-event-row';
    const left=document.createElement('div');
    const name=document.createElement('strong');name.textContent=ev.name;
    const meta=document.createElement('div');meta.className='meta';
    meta.textContent=`${formatDateDE(ev.start_date||'')} · ${eventStatus(ev)==='published'?'Veröffentlicht':'Entwurf'}`;
    left.append(name,meta);

    const actions=document.createElement('div');actions.className='publish-actions';
    const badge=document.createElement('span');badge.className='status-badge '+eventStatus(ev);
    badge.textContent=eventStatus(ev)==='published'?'Veröffentlicht':'Entwurf';
    const btn=document.createElement('button');btn.type='button';btn.className='secondary small';
    btn.textContent=eventStatus(ev)==='published'?'Zurück zu Entwurf':'Veröffentlichen';
    btn.onclick=()=>setEventStatus(ev.id,eventStatus(ev)==='published'?'draft':'published');
    actions.append(badge,btn);
    row.append(left,actions);box.appendChild(row);
  });
}

function currentEmployeePerson(){
  const uid=state.current_user?.person_id||state.current_user?.personId||'';
  return state.people.find(p=>p.id===uid)||null;
}

function employeePublishedShifts(){
  renderEmployeeAvailabilityDeadlines();
  const p=currentEmployeePerson();
  if(!p)return [];
  const publishedEventIds=new Set(state.events.filter(e=>eventStatus(e)==='published').map(e=>e.id));
  return state.assignments
    .filter(a=>a.person_id===p.id)
    .map(a=>state.shifts.find(s=>s.id===a.shift_id))
    .filter(Boolean)
    .filter(s=>publishedEventIds.has(s.event_id))
    .slice()
    .sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start));
}

async function createSwapRequest(shiftId){
  const p=currentEmployeePerson();if(!p){alert('Dein Benutzerkonto ist noch keiner Person zugeordnet.');return}
  const assignment=state.assignments.find(a=>a.shift_id===shiftId&&a.person_id===p.id);if(!assignment){alert('Zuweisung nicht gefunden.');return}
  const reason=prompt('Warum möchtest du diese Schicht tauschen?','');if(reason===null)return;
  try{await api('/api/swaps',{method:'POST',body:JSON.stringify({assignment_id:assignment.id,notes:reason})});setStatus('Tauschanfrage gesendet');await load()}catch(err){alert(err.message)}
}



function eventPoolPersonIds(eventId){return (state.event_people||[]).filter(x=>x.event_id===eventId).map(x=>x.person_id)}
function assignmentConfirmed(assignmentId){return (state.confirmations||[]).some(x=>x.assignment_id===assignmentId)}
async function confirmMyAssignment(assignmentId){
  try{await api('/api/confirm-assignment',{method:'POST',body:JSON.stringify({assignment_id:assignmentId})});setStatus('Schicht bestätigt');await load()}
  catch(err){alert(err.message)}
}
async function reviewSignup(id,status){
  try{await api('/api/signup_requests/'+id,{method:'PATCH',body:JSON.stringify({status})});await load()}
  catch(err){alert(err.message)}
}
async function promoteWaitlist(id){
  try{await api('/api/waitlist/'+id,{method:'PATCH',body:JSON.stringify({status:'promoted'})});await load()}
  catch(err){alert(err.message)}
}
function renderSignupManagement(){
  const reqBox=$('#signupRequestList'), waitBox=$('#waitlistManagerList');
  if(reqBox){
    reqBox.innerHTML='';const rows=(state.signup_requests||[]).filter(x=>x.status==='pending');
    if(!rows.length)reqBox.innerHTML='<div class="empty">Keine offenen Anmeldungen.</div>';
    rows.forEach(x=>{
      const sh=state.shifts.find(s=>s.id===x.shift_id),p=personBy(x.person_id);
      const d=document.createElement('div');d.className='item';
      d.innerHTML=`<div><div class="title">${p?.name||''} · ${sh?.name||'Schicht'}</div><div class="meta">${sh?.date?formatDateDE(sh.date):''} ${sh?.start||''}–${sh?.end||''}</div></div><div class="button-row"><button class="primary small" data-approve="${x.id}">Genehmigen</button><button class="danger small" data-reject="${x.id}">Ablehnen</button></div>`;
      reqBox.appendChild(d)
    });
    $$('[data-approve]').forEach(b=>b.onclick=()=>reviewSignup(b.dataset.approve,'approved'));
    $$('[data-reject]').forEach(b=>b.onclick=()=>reviewSignup(b.dataset.reject,'rejected'));
  }
  if(waitBox){
    waitBox.innerHTML='';const rows=(state.waitlist||[]).filter(x=>x.status==='waiting');
    if(!rows.length)waitBox.innerHTML='<div class="empty">Keine Personen auf Wartelisten.</div>';
    rows.forEach(x=>{
      const sh=state.shifts.find(s=>s.id===x.shift_id),p=personBy(x.person_id),free=sh?Math.max(0,Number(sh.required||1)-shiftAssignments(sh.id).length):0;
      const d=document.createElement('div');d.className='item';
      d.innerHTML=`<div><div class="title">${p?.name||''} · ${sh?.name||'Schicht'}</div><div class="meta">${sh?.date?formatDateDE(sh.date):''} · ${free} Platz/Plätze frei</div></div><button class="secondary small" data-promote="${x.id}" ${free?'':'disabled'}>Übernehmen</button>`;
      waitBox.appendChild(d)
    });
    $$('[data-promote]').forEach(b=>b.onclick=()=>promoteWaitlist(b.dataset.promote));
  }
}

function renderCloneEvent(){
  const sel=$('#cloneSourceEvent');if(!sel)return;const cur=sel.value;sel.innerHTML='';
  state.events.forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name;sel.appendChild(o)});if([...sel.options].some(o=>o.value===cur))sel.value=cur
}
function renderEventPool(){
  const evSel=$('#eventPoolEvent'),box=$('#eventPoolPeople'),mode=$('#eventSignupMode');if(!evSel||!box||!mode)return;
  const cur=evSel.value;evSel.innerHTML='';
  state.events.forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name;evSel.appendChild(o)});
  if([...evSel.options].some(o=>o.value===cur))evSel.value=cur;
  const ev=eventBy(evSel.value);mode.value=ev?.signup_mode||'direct';
  const selected=new Set(eventPoolPersonIds(evSel.value));box.innerHTML='';
  state.people.slice().sort((a,b)=>a.name.localeCompare(b.name,'de')).forEach(p=>{
    const label=document.createElement('label');label.className='event-pool-person';
    label.innerHTML=`<input type="checkbox" value="${p.id}" ${selected.has(p.id)?'checked':''}> <span>${p.name}</span>`;
    box.appendChild(label)
  })
}
function renderEmployeeSignupStatus(){
  const box=$('#employeeSignupStatus');if(!box)return;const p=currentEmployeePerson();box.innerHTML='';if(!p)return;
  const req=(state.signup_requests||[]).filter(x=>x.person_id===p.id).slice(-5).reverse();
  const waits=(state.waitlist||[]).filter(x=>x.person_id===p.id&&x.status==='waiting');
  if(!req.length&&!waits.length)return;
  const h=document.createElement('h4');h.textContent='Meine Anmeldungen';box.appendChild(h);
  req.forEach(x=>{const sh=state.shifts.find(s=>s.id===x.shift_id),d=document.createElement('div');d.className='mini-status';d.textContent=`${sh?.name||'Schicht'} · ${x.status}`;box.appendChild(d)});
  waits.forEach(x=>{const sh=state.shifts.find(s=>s.id===x.shift_id),d=document.createElement('div');d.className='mini-status';d.textContent=`${sh?.name||'Schicht'} · Warteliste`;box.appendChild(d)});
}

async function selfAssignToShift(shiftId){
  try{
    const result=await api('/api/self-assign',{method:'POST',body:JSON.stringify({shift_id:shiftId})});
    setStatus(result.status==='waitlisted'?'Du wurdest auf die Warteliste gesetzt.':result.status==='approval_required'?'Anmeldung zur Genehmigung gesendet.':'Du wurdest zur Schicht hinzugefügt.');
    await load();
  }catch(err){
    const details=err.payload?.conflicts?.length?'\n\n'+err.payload.conflicts.join('\n'):'';
    alert((err.message||'Zuweisung nicht möglich')+details);
  }
}

function renderEmployeeOpenShifts(){
  const box=$('#employeeOpenShiftList');if(!box)return;box.innerHTML='';
  const p=currentEmployeePerson();if(!p){box.innerHTML='<div class="empty">Dein Login ist noch keiner Person zugeordnet.</div>';return}
  const publishedIds=new Set(state.events.filter(e=>eventStatus(e)==='published').map(e=>e.id));
  const assignedShiftIds=new Set(state.assignments.filter(a=>a.person_id===p.id).map(a=>a.shift_id));
  const rows=state.shifts.filter(sh=>publishedIds.has(sh.event_id)&&sh.date>=todayISO()&&!assignedShiftIds.has(sh.id))
    .filter(sh=>{const pool=eventPoolPersonIds(sh.event_id);return !pool.length||pool.includes(p.id)})
    .filter(sh=>eventBy(sh.event_id)?.signup_mode!=='disabled')
    .slice().sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start));
  if(!rows.length){box.innerHTML='<div class="empty">Aktuell gibt es keine offenen Schichten für dich.</div>';return}
  rows.slice(0,20).forEach(sh=>{
    const ev=eventBy(sh.event_id),ass=shiftAssignments(sh.id),full=ass.length>=Number(sh.required||1);
    const av=personAvailabilityForShift(p.id,sh),rest=restConflictForCandidate(p.id,sh);
    const pending=(state.signup_requests||[]).some(x=>x.shift_id===sh.id&&x.person_id===p.id&&x.status==='pending');
    const waiting=(state.waitlist||[]).some(x=>x.shift_id===sh.id&&x.person_id===p.id&&x.status==='waiting');
    const row=document.createElement('div');row.className='employee-open-shift-row';
    const info=document.createElement('div');info.className='employee-open-shift-info';
    info.innerHTML=`<strong>${formatDateDE(sh.date)} · ${sh.name}</strong><span>${sh.start}–${sh.end} · ${ev?.name||''} · ${ass.length}/${sh.required} besetzt</span>`;
    const hint=document.createElement('span');hint.className='employee-open-shift-hint';
    const blocked=!av.ok?av.message:rest||'';
    hint.textContent=blocked?'⚠ '+blocked:(full?'Schicht voll – Warteliste möglich':ev?.signup_mode==='approval'?'Manager-Genehmigung erforderlich':av.status==='preferred'?'✓ Bevorzugte Verfügbarkeit':'✓ Direkte Anmeldung möglich');
    info.appendChild(hint);
    const btn=document.createElement('button');btn.type='button';btn.className='primary small';
    btn.textContent=pending?'Anfrage offen':waiting?'Auf Warteliste':full?'Auf Warteliste':'Mich eintragen';
    btn.disabled=Boolean(blocked||pending||waiting);btn.onclick=()=>selfAssignToShift(sh.id);
    row.append(info,btn);box.appendChild(row)
  })
}


function renderEmployeeAvailabilityDeadlines(){
  const box=$('#employeeAvailabilityDeadlines');if(!box)return;box.innerHTML='';
  const p=currentEmployeePerson();if(!p)return;
  const today=todayISO();
  const rows=(state.events||[]).filter(e=>e.status==='published'&&e.availability_deadline&&e.end_date>=today)
    .filter(e=>{const pool=eventPoolPersonIds(e.id);return !pool.length||pool.includes(p.id)})
    .sort((a,b)=>a.availability_deadline.localeCompare(b.availability_deadline));
  rows.slice(0,4).forEach(e=>{
    const responded=(state.availability||[]).some(a=>a.person_id===p.id&&a.date>=e.start_date&&a.date<=e.end_date);
    const div=document.createElement('div');div.className='employee-deadline-chip '+(responded?'done':'pending');
    div.textContent=`${responded?'✓':'⚠'} ${e.name}: Verfügbarkeit bis ${formatDateDE(e.availability_deadline)}${e.availability_locked?' · gesperrt':''}`;box.appendChild(div)
  })
}
function renderEmployeePortal(){
  const list=$('#employeeShiftList'), next=$('#employeeNextShift'), swaps=$('#employeeSwapList');
  if(!list||!next||!swaps)return;

  const p=currentEmployeePerson();
  if($('#employeeGreeting'))$('#employeeGreeting').textContent=p?`Hallo ${p.name}`:'Meine Schichten';

  if(!p){
    next.innerHTML='<div class="empty">Dein Login ist noch keiner Person zugeordnet. Ein Admin kann dies im Benutzerkonto hinterlegen.</div>';
    list.innerHTML='';swaps.innerHTML='';return;
  }

  const shifts=employeePublishedShifts();
  const future=shifts.filter(s=>s.date>=todayISO());

  next.innerHTML='';
  if(future.length){
    const sh=future[0], ev=eventBy(sh.event_id), leader=personBy(sh.leader_person_id);
    const assignment=state.assignments.find(a=>a.shift_id===sh.id&&a.person_id===p.id),confirmed=assignmentConfirmed(assignment?.id);
    next.innerHTML=`
      <div class="employee-next-label">Nächste Schicht</div>
      <div class="employee-next-date">${weekdayDE(sh.date)}, ${formatDateDE(sh.date)}</div>
      <div class="employee-next-name">${sh.name}</div>
      <div class="employee-next-time">${sh.start}–${sh.end}</div>
      <div class="employee-next-meta">${ev?.name||''}${ev?.location?` · ${ev.location}`:''}${leader?.name?` · Leitung: ${leader.name}`:''}</div>
      <div class="employee-next-details">${sh.meeting_point?`<span><b>Treffpunkt:</b> ${sh.meeting_point}</span>`:''}${sh.clothing?`<span><b>Kleidung:</b> ${sh.clothing}</span>`:''}${sh.instructions?`<span><b>Hinweise:</b> ${sh.instructions}</span>`:''}${sh.contact?`<span><b>Kontakt:</b> ${sh.contact}</span>`:''}</div>
      <div class="employee-next-confirm ${confirmed?'confirmed':'pending'}">${confirmed?'✓ Einsatz bestätigt':'⚠ Bestätigung ausstehend'}</div>
      ${assignment&&!confirmed?`<button id="confirmNextShift" class="primary" type="button">Diese Schicht bestätigen</button>`:''}
    `;
    if(assignment&&!confirmed&&$('#confirmNextShift'))$('#confirmNextShift').onclick=()=>confirmMyAssignment(assignment.id);
  }else{
    next.innerHTML='<div class="empty">Keine kommenden veröffentlichten Schichten.</div>';
  }

  list.innerHTML='';
  future.slice(0,12).forEach(sh=>{
    const ev=eventBy(sh.event_id), leader=personBy(sh.leader_person_id);
    const row=document.createElement('div');row.className='employee-shift-row';
    const info=document.createElement('div');
    info.innerHTML=`<strong>${formatDateDE(sh.date)} · ${sh.name}</strong><span>${sh.start}–${sh.end} · ${ev?.name||''}${leader?.name?` · Leitung: ${leader.name}`:''}</span>${sh.meeting_point?`<span>Treffpunkt: ${sh.meeting_point}</span>`:''}${sh.clothing?`<span>Kleidung: ${sh.clothing}</span>`:''}${sh.instructions?`<span>Hinweise: ${sh.instructions}</span>`:''}${sh.contact?`<span>Kontakt: ${sh.contact}</span>`:''}`;
    const actions=document.createElement('div');actions.className='employee-shift-actions';
    const assignment=state.assignments.find(a=>a.shift_id===sh.id&&a.person_id===p.id);
    const confirm=document.createElement('button');confirm.type='button';confirm.className=assignmentConfirmed(assignment?.id)?'secondary small':'primary small';
    confirm.textContent=assignmentConfirmed(assignment?.id)?'✓ Bestätigt':'Schicht bestätigen';confirm.disabled=assignmentConfirmed(assignment?.id);
    confirm.onclick=()=>confirmMyAssignment(assignment.id);
    const btn=document.createElement('button');btn.type='button';btn.className='secondary small';btn.textContent='Tausch anfragen';btn.onclick=()=>createSwapRequest(sh.id);
    actions.append(confirm,btn);row.append(info,actions);list.appendChild(row);
  });
  if(!future.length)list.innerHTML='<div class="empty">Keine kommenden Schichten.</div>';

  swaps.innerHTML='';
  const mine=(state.swaps||[]).filter(x=>x.requester_person_id===p.id||x.target_person_id===p.id);
  if(!mine.length){
    swaps.innerHTML='<div class="empty">Keine Tauschanfragen.</div>';
  }else{
    mine.slice().reverse().forEach(req=>{
      const sh=state.shifts.find(s=>s.id===req.shift_id);
      const row=document.createElement('div');row.className='employee-swap-row';
      row.innerHTML=`<strong>${sh?.name||'Schicht'}</strong><span>${sh?.date?formatDateDE(sh.date):''} · ${req.status||'pending'}${req.reason?` · ${req.reason}`:''}</span>`;
      swaps.appendChild(row);
    });
  }
}

function renderAvailability(){
  const form=$('#availabilityForm'), personSel=$('#availabilityPerson'),
        filterPerson=$('#availabilityFilterPerson'), list=$('#availabilityList');
  if(!form||!personSel||!filterPerson||!list)return;

  const current=personSel.value, currentFilter=filterPerson.value;
  const people=state.people.slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'));

  personSel.innerHTML='';
  filterPerson.innerHTML='<option value="">Alle Personen</option>';
  people.forEach(p=>{
    const a=document.createElement('option');a.value=p.id;a.textContent=p.name;personSel.appendChild(a);
    const b=document.createElement('option');b.value=p.id;b.textContent=p.name;filterPerson.appendChild(b);
  });
  if([...personSel.options].some(o=>o.value===current))personSel.value=current;
  if([...filterPerson.options].some(o=>o.value===currentFilter))filterPerson.value=currentFilter;

  const fp=filterPerson.value;
  const fd=$('#availabilityFilterDate')?.value||'';
  const rows=(state.availability||[])
    .filter(a=>(!fp||a.person_id===fp)&&(!fd||a.date===fd))
    .slice()
    .sort((a,b)=>(a.date+a.person_id).localeCompare(b.date+b.person_id));

  list.innerHTML='';
  if(!rows.length){
    list.innerHTML='<div class="empty">Keine Verfügbarkeiten für den Filter.</div>';
  }else{
    rows.forEach(a=>{
      const p=personBy(a.person_id);
      const row=document.createElement('div');row.className='availability-item';
      const left=document.createElement('div');
      const title=document.createElement('strong');title.textContent=`${p?.name||'Person'} · ${formatDateDE(a.date)}`;
      const meta=document.createElement('div');meta.className='meta';
      const labels={available:'Verfügbar',preferred:'Bevorzugt',unavailable:'Nicht verfügbar',vacation:'Ferien',sick:'Krank'};
      meta.textContent=`${labels[a.status]||a.status}${a.start&&a.end?` · ${a.start}–${a.end}`:''}${a.notes?` · ${a.notes}`:''}`;
      left.append(title,meta);
      const del=document.createElement('button');del.type='button';del.className='danger small';del.textContent='Löschen';
      del.onclick=()=>remove('availability',a.id);
      row.append(left,del);list.appendChild(row);
    });
  }
}

function renderWeekPlanner(){
  const board=$('#weekPlannerBoard');if(!board)return;
  const evSel=$('#weekEvent'), pSel=$('#weekPerson'), startInput=$('#weekStart');
  if(!evSel||!pSel||!startInput)return;

  const oldEv=evSel.value, oldP=pSel.value;
  evSel.innerHTML='<option value="">Alle Events</option>';
  state.events.slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de')).forEach(e=>{
    const o=document.createElement('option');o.value=e.id;o.textContent=e.name;evSel.appendChild(o);
  });
  if([...evSel.options].some(o=>o.value===oldEv))evSel.value=oldEv;

  pSel.innerHTML='<option value="">Alle Personen</option>';
  state.people.slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de')).forEach(p=>{
    const o=document.createElement('option');o.value=p.id;o.textContent=p.name;pSel.appendChild(o);
  });
  if([...pSel.options].some(o=>o.value===oldP))pSel.value=oldP;

  if(!startInput.value)startInput.value=mondayOf(todayISO());
  const weekStart=mondayOf(startInput.value);
  if(startInput.value!==weekStart)startInput.value=weekStart;

  const dates=Array.from({length:7},(_,i)=>addDaysISO(weekStart,i));
  const eventId=evSel.value, personId=pSel.value;

  let people=state.people.slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'));
  if(personId)people=people.filter(p=>p.id===personId);

  const shifts=state.shifts
    .filter(s=>dates.includes(s.date)&&(!eventId||s.event_id===eventId))
    .slice()
    .sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start));

  board.innerHTML='';

  const header=document.createElement('div');header.className='week-grid week-grid-header';
  const who=document.createElement('div');who.className='week-person-head';who.textContent='Person';
  header.appendChild(who);
  dates.forEach(d=>{
    const c=document.createElement('div');c.className='week-day-head';
    c.innerHTML=`<strong>${weekdayDE(d)}</strong><span>${formatDateDE(d)}</span>`;
    header.appendChild(c);
  });
  board.appendChild(header);

  people.forEach(p=>{
    const row=document.createElement('div');row.className='week-grid week-person-row';
    const label=document.createElement('div');label.className='week-person-cell';
    const h=weeklyHoursForPerson(p.id,weekStart);
    label.innerHTML=`<strong>${p.name}</strong><span>${h.toFixed(1)} h / Woche</span>`;
    row.appendChild(label);

    dates.forEach(date=>{
      const cell=document.createElement('div');cell.className='week-day-cell';
      const assigned=state.assignments
        .filter(a=>a.person_id===p.id)
        .map(a=>state.shifts.find(s=>s.id===a.shift_id))
        .filter(Boolean)
        .filter(s=>s.date===date&&(!eventId||s.event_id===eventId))
        .sort((a,b)=>a.start.localeCompare(b.start));

      const dayAvail=(state.availability||[]).filter(a=>a.person_id===p.id&&a.date===date);
      if(dayAvail.some(a=>['unavailable','vacation','sick'].includes(a.status)))cell.classList.add('week-unavailable');

      if(!assigned.length){
        const blank=document.createElement('span');blank.className='week-empty';
        blank.textContent=dayAvail.some(a=>a.status==='preferred')?'Bevorzugt verfügbar':'—';
        cell.appendChild(blank);
      }else{
        assigned.forEach(sh=>{
          const card=document.createElement('div');card.className='week-shift-chip';
          const issues=planningIssuesForShift(sh).filter(x=>x.startsWith(p.name+':'));
          if(issues.length)card.classList.add('has-warning');
          card.innerHTML=`<strong>${sh.name}</strong><span>${sh.start}–${sh.end}</span>${issues.length?'<em>⚠</em>':''}`;
          cell.appendChild(card);
        });
      }
      row.appendChild(cell);
    });
    board.appendChild(row);
  });

  renderPlannerWarnings(shifts);
}

function renderPlannerWarnings(shifts){
  const box=$('#plannerWarnings');if(!box)return;box.innerHTML='';
  const all=[];
  shifts.forEach(sh=>{
    planningIssuesForShift(sh).forEach(issue=>all.push({shift:sh,issue}));
  });

  if(!all.length){
    box.innerHTML='<div class="planner-warning-ok">✓ Keine Planungsprobleme in dieser Woche.</div>';
    return;
  }

  const head=document.createElement('div');head.className='planner-warning-head';
  head.textContent=`⚠ ${all.length} Warnung${all.length===1?'':'en'}`;
  box.appendChild(head);

  const list=document.createElement('div');list.className='planner-warning-list';
  all.slice(0,20).forEach(x=>{
    const item=document.createElement('div');item.className='planner-warning-item';
    item.textContent=`${formatDateDE(x.shift.date)} · ${x.shift.name}: ${x.issue}`;
    list.appendChild(item);
  });
  box.appendChild(list);
}

function renderCalendarFilters(){
  const es=$('#calendarEvent'), ds=$('#calendarDate'), ps=$('#calendarPerson');
  if(!es||!ds||!ps)return;

  const oldE=es.value, oldD=ds.value, oldP=ps.value;

  es.innerHTML='<option value="">Alle Events</option>';
  state.events
    .slice()
    .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'))
    .forEach(e=>{
      const o=document.createElement('option');
      o.value=e.id;
      o.textContent=e.name;
      es.appendChild(o);
    });
  if([...es.options].some(o=>o.value===oldE))es.value=oldE;

  const dates=[...new Set(
    state.shifts
      .filter(s=>!es.value||s.event_id===es.value)
      .map(s=>s.date)
      .filter(Boolean)
  )].sort();

  ds.innerHTML='<option value="">Alle Tage</option>';
  dates.forEach(date=>{
    const o=document.createElement('option');
    o.value=date;
    o.textContent=formatDateDE(date);
    ds.appendChild(o);
  });
  if([...ds.options].some(o=>o.value===oldD))ds.value=oldD;

  ps.innerHTML='<option value="">Alle Personen</option>';
  state.people
    .slice()
    .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'))
    .forEach(p=>{
      const o=document.createElement('option');
      o.value=p.id;
      o.textContent=p.name;
      ps.appendChild(o);
    });
  if([...ps.options].some(o=>o.value===oldP))ps.value=oldP;
}

function filteredCalendarShifts(){
  const eventId=$('#calendarEvent')?.value||'';
  const date=$('#calendarDate')?.value||'';
  const personId=$('#calendarPerson')?.value||'';

  return state.shifts
    .filter(s=>(!eventId||s.event_id===eventId)&&(!date||s.date===date))
    .filter(s=>{
      if(!personId)return true;
      return state.assignments.some(a=>a.shift_id===s.id&&a.person_id===personId);
    })
    .slice()
    .sort((a,b)=>(a.date+a.start+a.end+a.name).localeCompare(b.date+b.start+b.end+b.name));
}

function weekdayDE(iso){
  if(!iso)return '';
  const d=new Date(iso+'T12:00:00');
  if(Number.isNaN(d.getTime()))return '';
  return new Intl.DateTimeFormat('de-CH',{weekday:'long'}).format(d);
}

function renderTimeline(){
  const box=$('#timelineView');if(!box)return;box.innerHTML='';
  const shifts=filteredCalendarShifts();

  if(!shifts.length){
    box.innerHTML='<div class="empty">Keine Schichten für die gewählten Kalenderfilter.</div>';
    return;
  }

  const dates=[...new Set(shifts.map(s=>s.date))].sort();

  dates.forEach(date=>{
    const dayShifts=shifts.filter(s=>s.date===date);

    const row=document.createElement('section');
    row.className='calendar-day-row';

    const day=document.createElement('div');
    day.className='calendar-day-label';

    const weekday=document.createElement('div');
    weekday.className='calendar-weekday';
    weekday.textContent=weekdayDE(date);

    const dateText=document.createElement('div');
    dateText.className='calendar-date';
    dateText.textContent=formatDateDE(date);

    const count=document.createElement('div');
    count.className='calendar-day-count';
    count.textContent=`${dayShifts.length} Schicht${dayShifts.length===1?'':'en'}`;

    day.append(weekday,dateText,count);

    const track=document.createElement('div');
    track.className='calendar-shift-track';

    dayShifts.forEach(sh=>{
      const ass=shiftAssignments(sh.id);
      const leader=personBy(sh.leader_person_id);
      const ev=eventBy(sh.event_id);

      const card=document.createElement('article');
      card.className='calendar-shift-card';

      const top=document.createElement('div');
      top.className='calendar-shift-top';

      const time=document.createElement('div');
      time.className='calendar-shift-time';
      time.textContent=`${sh.start}–${sh.end}`;

      const coverage=document.createElement('span');
      coverage.className='coverage-pill '+(ass.length>=Number(sh.required||1)?'good':'bad');
      coverage.textContent=`${ass.length}/${sh.required}`;

      top.append(time,coverage);

      const title=document.createElement('div');
      title.className='calendar-shift-title';
      title.textContent=sh.name;

      const eventLine=document.createElement('div');
      eventLine.className='calendar-shift-event';
      eventLine.textContent=ev?.name||'Event';

      const leaderLine=document.createElement('div');
      leaderLine.className='calendar-shift-leader';
      leaderLine.textContent=`Schichtleiter: ${leader?.name||'Nicht gesetzt'}`;

      const people=document.createElement('div');
      people.className='calendar-shift-people';

      if(!ass.length){
        const empty=document.createElement('span');
        empty.className='calendar-person-empty';
        empty.textContent='Noch niemand eingeteilt';
        people.appendChild(empty);
      }else{
        ass.forEach(a=>{
          const p=personBy(a.person_id);
          if(!p)return;
          const chip=document.createElement('span');
          chip.className='calendar-person-chip';
          chip.textContent=p.name;
          people.appendChild(chip);
        });
      }

      card.append(top,title,eventLine,leaderLine,people);

      if(sh.notes){
        const notes=document.createElement('div');
        notes.className='calendar-shift-notes';
        notes.textContent=sh.notes;
        card.appendChild(notes);
      }

      track.appendChild(card);
    });

    row.append(day,track);
    box.appendChild(row);
  });
}

function exportPlanXlsx(){const e=$('#plannerEvent')?.value||'',d=$('#plannerDate')?.value||'',q=new URLSearchParams();if(e)q.set('event_id',e);if(d)q.set('date',d);window.location.href=apiUrl('/api/export.xlsx?'+q.toString());setStatus('Excel export started')}

async function createShiftFromTemplate(t){
  if(!t.event_id){alert('Diese Schichtvorlage ist noch keinem Event zugeordnet. Bitte Vorlage bearbeiten.');return}
  if(!t.date){alert('Diese Schichtvorlage hat noch kein Datum. Bitte Vorlage bearbeiten.');return}

  const existing=shiftForTemplate(t);
  if(existing){
    setStatus('Schicht existiert bereits');
    alert('Diese Schicht wurde bereits aus der Vorlage erstellt. Weitere Personen werden derselben Schicht zugewiesen.');
    return existing;
  }

  try{
    const shift=await api('/api/shifts',{
      method:'POST',
      body:JSON.stringify({
        event_id:t.event_id,
        leader_person_id:t.leader_person_id||'',
        name:t.name,
        role:t.role,
        date:t.date,
        start:t.start,
        end:t.end,
        required:t.required,
        notes:t.notes
      })
    });
    setStatus('Schicht aus Vorlage erstellt');
    await load();
    return shift;
  }catch(err){
    alert(err.message);
    return null;
  }
}
function csvCell(v){
  const s=String(v??'');
  return /[",\n]/.test(s)?'"'+s.replaceAll('"','""')+'"':s;
}
function exportPlanCsv(){
  const shifts=filteredPlannerShifts();
  const rows=[['Event','Date','Shift','Schichtleiter','Start','End','Required','Assigned','Person','Email','Phone']];
  shifts.forEach(s=>{
    const ass=shiftAssignments(s.id);
    if(!ass.length) rows.push([eventBy(s.event_id)?.name||'',s.date,s.name,s.role,s.start,s.end,s.required,0,'','','','']);
    ass.forEach(a=>{
      const p=personBy(a.person_id)||{};
      rows.push([eventBy(s.event_id)?.name||'',s.date,s.name,s.role,s.start,s.end,s.required,ass.length,p.name||'','',p.email||'',p.phone||'']);
    });
  });
  const csv='\ufeff'+rows.map(r=>r.map(csvCell).join(';')).join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob), a=document.createElement('a');
  const e=$('#plannerEvent')?.value, d=$('#plannerDate')?.value;
  a.href=url;a.download=`shift-plan${e?'-'+(eventBy(e)?.name||'event').replace(/[^a-z0-9]+/gi,'-') : ''}${d?'-'+d:''}.csv`;
  document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);setStatus('CSV exported');
}


function downloadCsv(filename, rows){
  const csv='\ufeff'+rows.map(r=>r.map(csvCell).join(';')).join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url;a.download=filename;
  document.body.appendChild(a);a.click();a.remove();
  URL.revokeObjectURL(url);
}
function savePeopleCsv(){
  const rows=[['Name','Role','Email','Phone','MaxHoursDay']];
  state.people.forEach(p=>rows.push([p.name||'','',p.email||'',p.phone||'',p.max_hours_day??10]));
  downloadCsv('people.csv',rows);
  setStatus('People saved');
}
function saveEventsCsv(){
  const rows=[['Name','Location','StartDate','EndDate','Notes']];
  state.events.forEach(e=>rows.push([e.name||'',e.location||'',e.start_date||'',e.end_date||'',e.notes||'']));
  downloadCsv('events.csv',rows);
  setStatus('Events saved');
}
function parseCsv(text){
  text=text.replace(/^\ufeff/,'');
  const rows=[];let row=[],cell='',quoted=false;
  for(let i=0;i<text.length;i++){
    const c=text[i],n=text[i+1];
    if(c==='"'){
      if(quoted&&n==='"'){cell+='"';i++}else quoted=!quoted;
    }else if((c===';'||c===',')&&!quoted){
      row.push(cell);cell='';
    }else if((c==='\n'||c==='\r')&&!quoted){
      if(c==='\r'&&n==='\n')i++;
      row.push(cell);
      if(row.some(x=>x!==''))rows.push(row);
      row=[];cell='';
    }else{
      cell+=c;
    }
  }
  row.push(cell);
  if(row.some(x=>x!==''))rows.push(row);
  return rows;
}
function normHeader(s){
  return String(s||'').trim().toLowerCase().replace(/[^a-z0-9]/g,'');
}
async function importPeopleCsv(file){
  if(!file)return;
  try{
    const rows=parseCsv(await file.text());
    if(rows.length<2)throw new Error('No people rows found');
    const headers=rows[0].map(normHeader);
    const idx=k=>headers.indexOf(k);
    let added=0,failed=0,skipped=0;
    const existingNames=new Set(state.people.map(p=>String(p.name||'').trim().toLowerCase()));
    for(const r of rows.slice(1)){
      const body={
        name:(r[idx('name')]||'').trim(),
        role:idx('role')>=0?r[idx('role')]||'':'',
        email:idx('email')>=0?r[idx('email')]||'':'',
        phone:idx('phone')>=0?r[idx('phone')]||'':'',
        max_hours_day:idx('maxhoursday')>=0?Number(r[idx('maxhoursday')]||10):10
      };
      if(!body.name)continue;
      const normalizedName=body.name.toLowerCase();
      if(existingNames.has(normalizedName)){
        skipped++;
        continue;
      }
      try{
        await api('/api/people',{method:'POST',body:JSON.stringify(body)});
        existingNames.add(normalizedName);
        added++;
      }catch{
        failed++;
      }
    }
    await load();
    alert(`People import finished: ${added} added, ${skipped} skipped because the name already exists${failed?`, ${failed} failed`:''}.`);
  }catch(err){
    alert('People import failed: '+err.message);
  }finally{
    const input=$('#importPeopleFile');
    if(input)input.value='';
  }
}
async function importEventsCsv(file){
  if(!file)return;
  try{
    const rows=parseCsv(await file.text());
    if(rows.length<2)throw new Error('No event rows found');
    const headers=rows[0].map(normHeader);
    const idx=k=>headers.indexOf(k);
    let added=0,failed=0;
    for(const r of rows.slice(1)){
      const body={
        name:r[idx('name')]||'',
        location:idx('location')>=0?r[idx('location')]||'':'',
        start_date:idx('startdate')>=0?r[idx('startdate')]||'':'',
        end_date:idx('enddate')>=0?r[idx('enddate')]||'':'',
        notes:idx('notes')>=0?r[idx('notes')]||'':''
      };
      if(!body.name||!body.start_date||!body.end_date)continue;
      try{
        await api('/api/events',{method:'POST',body:JSON.stringify(body)});
        added++;
      }catch{
        failed++;
      }
    }
    await load();
    alert(`Event import finished: ${added} added${failed?`, ${failed} failed`:''}.`);
  }catch(err){
    alert('Event import failed: '+err.message);
  }finally{
    const input=$('#importEventsFile');
    if(input)input.value='';
  }
}


function exportShiftsCsv(){
  const rows=[['Event','Name','Schichtleiter','Date','Start','End','Required','Notes']];
  [...state.shifts]
    .sort((a,b)=>(a.date+a.start+a.name).localeCompare(b.date+b.start+b.name))
    .forEach(s=>{
      const ev=eventBy(s.event_id);
      const leader=personBy(s.leader_person_id);
      rows.push([
        ev?.name||'',
        s.name||'',
        leader?.name||'',
        s.date||'',
        s.start||'',
        s.end||'',
        s.required??1,
        s.notes||''
      ]);
    });
  downloadCsv('schichten.csv',rows);
  setStatus('Schichten gespeichert');
}

function downloadShiftTemplateCsv(){
  const rows=[
    ['Event','Name','Schichtleiter','Date','Start','End','Required','Notes'],
    ['Höckeler Sommerfest','Aufbau','Max Muster','2026-07-11','08:00','12:00','2','Material vorbereiten'],
    ['Höckeler Sommerfest','Bar Abend','Anna Beispiel','2026-07-11','18:00','23:00','3','']
  ];
  downloadCsv('schichten_import_vorlage.csv',rows);
  setStatus('CSV Vorlage erstellt');
}

async function importShiftsCsv(file){
  if(!file)return;
  try{
    const rows=parseCsv(await file.text());
    if(rows.length<2)throw new Error('Keine Schichten in der CSV gefunden');

    const headers=rows[0].map(normHeader);
    const idx=k=>headers.indexOf(k);

    const requiredHeaders=['event','name','date','start','end'];
    const missingHeaders=requiredHeaders.filter(h=>idx(h)<0);
    if(missingHeaders.length){
      throw new Error('Fehlende Spalten: '+missingHeaders.join(', '));
    }

    const eventMap=new Map(
      state.events.map(e=>[String(e.name||'').trim().toLowerCase(),e])
    );

    const existingShiftKeys=new Set(
      state.shifts.map(s=>{
        const ev=eventBy(s.event_id);
        return [
          String(ev?.name||'').trim().toLowerCase(),
          String(s.name||'').trim().toLowerCase(),
          String(s.date||'').trim(),
          String(s.start||'').trim()
        ].join('|');
      })
    );

    let added=0,skipped=0,missingEvent=0,failed=0;
    const missingEventNames=new Set();

    for(const row of rows.slice(1)){
      const eventName=String(row[idx('event')]||'').trim();
      const name=String(row[idx('name')]||'').trim();
      const leaderCol=idx('schichtleiter')>=0?idx('schichtleiter'):idx('role');
      const leaderName=leaderCol>=0?String(row[leaderCol]||'').trim():'';
      let leader_person_id='';
      if(leaderName){
        const leader=state.people.find(p=>String(p.name||'').trim().toLowerCase()===leaderName.toLowerCase());
        if(!leader){failed++;continue}
        leader_person_id=leader.id;
      }
      const date=String(row[idx('date')]||'').trim();
      const start=String(row[idx('start')]||'').trim();
      const end=String(row[idx('end')]||'').trim();
      const required=idx('required')>=0?Number(row[idx('required')]||1):1;
      const notes=idx('notes')>=0?String(row[idx('notes')]||'').trim():'';

      if(!eventName&&!name&&!date&&!start&&!end)continue;
      if(!eventName||!name||!date||!start||!end){failed++;continue}

      const event=eventMap.get(eventName.toLowerCase());
      if(!event){
        missingEvent++;
        missingEventNames.add(eventName);
        continue;
      }

      const key=[
        eventName.toLowerCase(),
        name.toLowerCase(),
        date,
        start
      ].join('|');

      if(existingShiftKeys.has(key)){
        skipped++;
        continue;
      }

      try{
        await api('/api/shifts',{
          method:'POST',
          body:JSON.stringify({
            event_id:event.id,
            name,
            leader_person_id,
            date,
            start,
            end,
            required:Number.isFinite(required)&&required>0?required:1,
            notes
          })
        });
        existingShiftKeys.add(key);
        added++;
      }catch{
        failed++;
      }
    }

    await load();

    let msg=`Schichten-Import abgeschlossen: ${added} hinzugefügt, ${skipped} Duplikate übersprungen`;
    if(missingEvent)msg+=`, ${missingEvent} ohne passendes Event`;
    if(failed)msg+=`, ${failed} fehlerhaft`;
    if(missingEventNames.size){
      msg+=`.\n\nNicht gefundene Events:\n${[...missingEventNames].join('\n')}`;
    }else{
      msg+='.';
    }
    alert(msg);

  }catch(err){
    alert('Schichten-Import fehlgeschlagen: '+err.message);
  }finally{
    const input=$('#importShiftsFile');
    if(input)input.value='';
  }
}

function backupPlannerData(){
  window.location.href=apiUrl('/api/backup');
  setStatus('Backup export started');
}
async function restorePlannerData(file){
  if(!file)return;
  try{
    const text=await file.text();
    const data=JSON.parse(text);
    if(!confirm('Restore this backup? Current events, people, shifts, templates and assignments will be replaced.'))return;
    await api('/api/restore',{method:'POST',body:JSON.stringify(data)});
    setStatus('Backup restored');
    await load();
  }catch(err){
    alert('Restore failed: '+err.message);
  }finally{
    const input=$('#restoreFile');
    if(input)input.value='';
  }
}

async function remove(kind,id){
  if(!confirm('Delete this item?'))return;
  await api(`/api/${kind}/${id}`,{method:'DELETE'}); setStatus('Deleted'); await load();
}
function formJSON(form){return Object.fromEntries(new FormData(form).entries())}
$('#eventForm').onsubmit=async e=>{e.preventDefault();try{const b=formJSON(e.target);b.availability_locked=e.target.elements.availability_locked.checked;await api('/api/events',{method:'POST',body:JSON.stringify(b)});e.target.reset();setStatus('Event created');await load()}catch(x){alert(x.message)}};
$('#personForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/people',{method:'POST',body:JSON.stringify(formJSON(e.target))});e.target.reset();setStatus('Person added');await load()}catch(x){alert(x.message)}};
$('#shiftForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/shifts',{method:'POST',body:JSON.stringify(formJSON(e.target))});e.target.reset();setStatus('Shift created');await load()}catch(x){alert(x.message)}};
$('#templateForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/templates',{method:'POST',body:JSON.stringify(formJSON(e.target))});e.target.reset();setStatus('Schichtvorlage gespeichert');await load()}catch(x){alert(x.message)}};
$('#plannerEvent').onchange=()=>{renderPlannerFilters();renderPlannerPeoplePalette();renderShiftAssignmentBoard();renderDropBoard()};
$('#plannerDate').onchange=()=>{renderPlannerPeoplePalette();renderShiftAssignmentBoard();renderDropBoard()};
$('#plannerPerson').onchange=()=>{renderPlannerPeoplePalette();renderShiftAssignmentBoard();renderDropBoard()};

if($('#availabilityForm')) $('#availabilityForm').onsubmit=async e=>{
  e.preventDefault();
  const f=Object.fromEntries(new FormData(e.currentTarget).entries());
  try{
    await api('/api/availability',{method:'POST',body:JSON.stringify(f)});
    e.currentTarget.reset();
    setStatus('Verfügbarkeit gespeichert');
    await load();
  }catch(err){alert(err.message)}
};
if($('#availabilityFilterPerson')) $('#availabilityFilterPerson').onchange=renderAvailability;
if($('#availabilityFilterDate')) $('#availabilityFilterDate').onchange=renderAvailability;

if($('#weekEvent')) $('#weekEvent').onchange=renderWeekPlanner;
if($('#weekPerson')) $('#weekPerson').onchange=renderWeekPlanner;
if($('#weekStart')) $('#weekStart').onchange=renderWeekPlanner;
if($('#weekPrev')) $('#weekPrev').onclick=()=>{
  const el=$('#weekStart');el.value=addDaysISO(mondayOf(el.value||todayISO()),-7);renderWeekPlanner();
};
if($('#weekNext')) $('#weekNext').onclick=()=>{
  const el=$('#weekStart');el.value=addDaysISO(mondayOf(el.value||todayISO()),7);renderWeekPlanner();
};
if($('#weekToday')) $('#weekToday').onclick=()=>{
  $('#weekStart').value=mondayOf(todayISO());renderWeekPlanner();
};

if($('#calendarEvent')) $('#calendarEvent').onchange=()=>{renderCalendarFilters();renderTimeline()};
if($('#calendarDate')) $('#calendarDate').onchange=renderTimeline;
if($('#calendarPerson')) $('#calendarPerson').onchange=renderTimeline;
if($('#calendarReset')) $('#calendarReset').onclick=()=>{
  if($('#calendarEvent'))$('#calendarEvent').value='';
  renderCalendarFilters();
  if($('#calendarDate'))$('#calendarDate').value='';
  if($('#calendarPerson'))$('#calendarPerson').value='';
  renderTimeline();
};
if($('#savePeople')) $('#savePeople').onclick=savePeopleCsv;
if($('#importPeople')) $('#importPeople').onclick=()=>$('#importPeopleFile')?.click();
if($('#importPeopleFile')) $('#importPeopleFile').onchange=e=>importPeopleCsv(e.target.files?.[0]);
if($('#saveEvents')) $('#saveEvents').onclick=saveEventsCsv;
if($('#importEvents')) $('#importEvents').onclick=()=>$('#importEventsFile')?.click();
if($('#importEventsFile')) $('#importEventsFile').onchange=e=>importEventsCsv(e.target.files?.[0]);
if($('#importShifts')) $('#importShifts').onclick=()=>$('#importShiftsFile')?.click();
if($('#exportShifts')) $('#exportShifts').onclick=exportShiftsCsv;
if($('#importShiftsFile')) $('#importShiftsFile').onchange=e=>importShiftsCsv(e.target.files?.[0]);
if($('#downloadShiftTemplate')) $('#downloadShiftTemplate').onclick=downloadShiftTemplateCsv;
if($('#backupData')) $('#backupData').onclick=backupPlannerData;
if($('#restoreData')) $('#restoreData').onclick=()=>$('#restoreFile')?.click();
if($('#restoreFile')) $('#restoreFile').onchange=e=>restorePlannerData(e.target.files?.[0]);
if($('#exportXlsx')) $('#exportXlsx').onclick=exportPlanXlsx;
if($('#exportCsv')) $('#exportCsv').onclick=exportPlanCsv;
if($('#printPlan')) $('#printPlan').onclick=()=>window.print();

function initCollapsibles(){
  $$('[data-collapse]').forEach(btn=>{
    btn.onclick=()=>{
      const id=btn.dataset.collapse;
      const body=$('#'+id);
      if(!body)return;
      const collapsed=body.classList.toggle('collapsed');
      btn.setAttribute('aria-expanded',String(!collapsed));
      const sym=btn.querySelector('.collapse-symbol');
      if(sym)sym.textContent=collapsed?'+':'−';
    };
  });
}

function openView(view,label){
  $$('.nav').forEach(x=>x.classList.toggle('active',x.dataset.view===view));
  $$('.view').forEach(v=>v.classList.add('hidden'));
  const target=$('#'+view);if(target)target.classList.remove('hidden');
  if(view==='shiftcalendar'){renderCalendarFilters();renderTimeline()} if(view==='availability'){renderAvailability()} if(view==='weekplanner'){renderWeekPlanner()} if(view==='employeeportal'){renderEmployeePortal();renderEmployeeOpenShifts();renderEmployeeAvailability();renderEmployeeSignupStatus()} if(view==='signups'){renderSignupManagement()} if(view==='eventcockpit'){renderEventCockpit()} if(view==='reports'){renderReports()}
  if($('#pageTitle'))$('#pageTitle').textContent=label||($(`.nav[data-view="${view}"]`)?.textContent.trim()||view);
  window.scrollTo({top:0,behavior:'smooth'});
}
$$('.nav').forEach(b=>b.onclick=()=>openView(b.dataset.view,b.textContent.trim()));
$$('[data-go]').forEach(b=>b.onclick=()=>openView(b.dataset.go,b.textContent.trim()));
initAuth();

if($('#themeToggle')) $('#themeToggle').onclick=toggleTheme;
if($('#settingsThemeButton')) $('#settingsThemeButton').onclick=toggleTheme;
if($('#peopleSearch')) $('#peopleSearch').oninput=renderPeople;


try{initTheme()}catch(e){console.warn('Theme init failed',e)}

initCollapsibles();


function exportGraphicalPlanningPdf(){
  const source =
    $('#timelineView') ||
    $('#timeline') ||
    $('#graphicalPlanning') ||
    $('#planningOverview') ||
    $('#timelineView');

  if(!source){
    alert('Die grafische Schichtplanung wurde nicht gefunden.');
    return;
  }

  const eventFilter=$('#calendarEvent');
  const dateFilter=$('#calendarDate');
  const selectedEvent=eventFilter?.selectedOptions?.[0]?.textContent?.trim()||'Alle Events';
  const selectedDate=dateFilter?.selectedOptions?.[0]?.textContent?.trim()||'Alle Tage';
  const personFilter=$('#calendarPerson');
  const selectedPerson=personFilter?.selectedOptions?.[0]?.textContent?.trim()||'Alle Personen';

  const popup=window.open('','_blank','width=1200,height=850');
  if(!popup){
    alert('Das PDF-Fenster wurde vom Browser blockiert. Bitte Pop-ups für diese Seite erlauben.');
    return;
  }

  const cloned=source.cloneNode(true);
  cloned.querySelectorAll('button,.button-row,.drop-hint').forEach(el=>el.remove());

  const title='Höckeler – Grafische Schichtplanung';
  const subtitle=`Event: ${selectedEvent} · Tag: ${selectedDate} · Person: ${selectedPerson}`;

  popup.document.open();
  popup.document.write(`<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<title>${title}</title>
<style>
  @page { size: A4 landscape; margin: 12mm; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    color: #111827;
    background: #fff;
    font-size: 11pt;
  }
  .pdf-header {
    border-bottom: 2px solid #111827;
    padding-bottom: 8px;
    margin-bottom: 14px;
  }
  .pdf-header h1 { margin: 0 0 5px; font-size: 20pt; }
  .pdf-header .subtitle { color: #4b5563; font-size: 10pt; }
  .timeline-day, .day-block, .planner-day {
    break-inside: avoid;
    page-break-inside: avoid;
    margin: 0 0 14px;
  }
  .shift-card, .timeline-shift, .planner-shift {
    break-inside: avoid;
    page-break-inside: avoid;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
    padding: 9px;
    margin: 7px 0;
    background: #fff !important;
    color: #111827 !important;
  }
  .title { font-weight: 700; font-size: 12pt; }
  .meta, .shift-time, .shift-role, .shift-assigned {
    color: #374151 !important;
    margin-top: 3px;
  }
  .person-chip, .chip, .assignment {
    display: inline-block;
    border: 1px solid #d1d5db;
    border-radius: 12px;
    padding: 3px 7px;
    margin: 3px 4px 3px 0;
    background: #f8fafc !important;
    color: #111827 !important;
  }
  .calendar-day-row {
    display: grid;
    grid-template-columns: 42mm 1fr;
    gap: 6mm;
    align-items: start;
    border-bottom: 1px solid #d1d5db;
    padding: 4mm 0;
    break-inside: avoid;
  }
  .calendar-day-label {
    border-right: 1px solid #d1d5db;
    padding-right: 4mm;
  }
  .calendar-weekday { font-weight: 700; text-transform: capitalize; }
  .calendar-date { font-size: 13pt; font-weight: 800; margin-top: 1mm; }
  .calendar-day-count { color: #6b7280; margin-top: 2mm; font-size: 9pt; }
  .calendar-shift-track {
    display: flex;
    gap: 4mm;
    align-items: stretch;
    overflow: visible;
  }
  .calendar-shift-card {
    min-width: 54mm;
    max-width: 70mm;
    border: 1px solid #9ca3af;
    border-radius: 3mm;
    padding: 3mm;
    break-inside: avoid;
    background: #fff !important;
    color: #111827 !important;
  }
  .calendar-shift-top { display:flex; justify-content:space-between; gap:3mm; }
  .calendar-shift-time { font-weight:800; }
  .calendar-shift-title { font-weight:800; font-size:11pt; margin-top:2mm; }
  .calendar-shift-event, .calendar-shift-leader, .calendar-shift-notes {
    color:#4b5563 !important;
    font-size:8.5pt;
    margin-top:1mm;
  }
  .calendar-shift-people { margin-top:2mm; display:flex; flex-wrap:wrap; gap:1mm; }
  .calendar-person-chip {
    border:1px solid #d1d5db;
    border-radius:99px;
    padding:1mm 2mm;
    font-size:8pt;
  }
  button, input, select, textarea { display: none !important; }
</style>
</head>
<body>
  <div class="pdf-header">
    <h1>${title}</h1>
    <div class="subtitle">${subtitle}</div>
  </div>
  <div id="printPlanning"></div>
<script>
  document.getElementById('printPlanning').appendChild(
    document.importNode(${JSON.stringify(cloned.outerHTML) ? "new DOMParser().parseFromString(" + JSON.stringify(cloned.outerHTML) + ",'text/html').body.firstElementChild" : "document.createElement('div')"}, true)
  );
  window.addEventListener('load',()=>setTimeout(()=>window.print(),250));
<\/script>
</body>
</html>`);
  popup.document.close();
}


document.addEventListener('DOMContentLoaded',()=>{
  const pdfBtn=$('#exportPlanningPdf');
  if(pdfBtn) pdfBtn.addEventListener('click',exportGraphicalPlanningPdf);
});


function showLogin(){
  const x=$('#loginOverlay');if(x)x.classList.remove('hidden');
}
function hideLogin(){
  const x=$('#loginOverlay');if(x)x.classList.add('hidden');
}
function userRole(){return state.current_user?.role||''}
function isManager(){return ['admin','manager'].includes(userRole())}

function applyRoleNavigation(){
  const employee=state.current_user?.role==='employee';
  $$('.employee-nav').forEach(x=>x.classList.toggle('hidden',!employee));
  $$('.manager-only').forEach(x=>x.classList.toggle('hidden',employee));
  const managerViews=['events','people','templates','shifts','planner','weekplanner','availability','export','backup','settings'];
  managerViews.forEach(v=>{
    const nav=$(`.nav[data-view="${v}"]`);
    if(nav)nav.classList.toggle('hidden',employee);
  });
}

function applyPermissions(){
  const role=userRole();
  $$('.admin-only').forEach(x=>x.classList.toggle('hidden',role!=='admin'));
  $$('.manager-only').forEach(x=>x.classList.toggle('hidden',!['admin','manager'].includes(role)));
  $$('.employee-only').forEach(x=>x.classList.toggle('hidden',role!=='employee'));
  // Existing management sections stay visible for managers/admins only.
  ['events','people','templates','shifts','data','backup'].forEach(v=>{
    const n=$(`.nav[data-view="${v}"]`);if(n)n.classList.toggle('hidden',role==='employee');
  });
  if($('#userPill'))$('#userPill').textContent=`${state.current_user?.display_name||state.current_user?.username||''} · ${role==='manager'?'Event Manager':role==='employee'?'Employee':'Admin'}`;
}
async function initAuth(){
  if($('#loginForm'))$('#loginForm').onsubmit=async e=>{
    e.preventDefault();$('#loginError').textContent='';
    try{await api('/api/login',{method:'POST',body:JSON.stringify(formJSON(e.target))});e.target.reset();await load()}catch(err){$('#loginError').textContent=err.message}
  };
  if($('#logoutButton'))$('#logoutButton').onclick=async()=>{try{await api('/api/logout',{method:'POST',body:'{}'})}finally{state.current_user=null;showLogin()}};
  await load().catch(e=>{console.error(e);showLogin()});
}
function renderEnterpriseViews(){renderSwaps();renderNotifications();renderUsers();}
function hoursForPersonOnDate(pid,date){
  return state.assignments.filter(a=>a.person_id===pid).map(a=>state.shifts.find(s=>s.id===a.shift_id)).filter(s=>s&&s.date===date).reduce((n,s)=>n+durationMinutes(s.start,s.end)/60,0);
}
function mondayISO(d=new Date()){
  const x=new Date(d);const day=(x.getDay()+6)%7;x.setDate(x.getDate()-day);return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`
}
function renderSwaps(){
  const assSel=$('#swapAssignment'),target=$('#swapTarget');if(assSel){const cur=assSel.value;assSel.innerHTML='';state.assignments.forEach(a=>{const sh=state.shifts.find(s=>s.id===a.shift_id),p=personBy(a.person_id);if(!sh)return;const o=document.createElement('option');o.value=a.id;o.textContent=`${formatDateDE(sh.date)} ${sh.start} ${sh.name} · ${p?.name||''}`;assSel.appendChild(o)});if([...assSel.options].some(o=>o.value===cur))assSel.value=cur}
  if(target){const cur=target.value;target.innerHTML='<option value="">Offen</option>';state.people.forEach(p=>{const o=document.createElement('option');o.value=p.id;o.textContent=p.name;target.appendChild(o)});if([...target.options].some(o=>o.value===cur))target.value=cur}
  const pending=(state.swaps||[]).filter(x=>x.status==='pending').length;if($('#swapPendingCount'))$('#swapPendingCount').textContent=`${pending} offen`;const box=$('#swapList');if(!box)return;box.innerHTML='';if(!(state.swaps||[]).length){box.innerHTML='<div class="empty">Keine Tauschanfragen.</div>';return}
  [...state.swaps].sort((a,b)=>(b.created_at||'').localeCompare(a.created_at||'')).forEach(sw=>{const ass=state.assignments.find(a=>a.id===sw.assignment_id),sh=ass&&state.shifts.find(s=>s.id===ass.shift_id);const d=document.createElement('div');d.className='item swap-review-item';const opts=state.people.map(p=>`<option value="${p.id}" ${p.id===sw.target_person_id?'selected':''}>${p.name}</option>`).join('');const actions=isManager()&&sw.status==='pending'?`<div class="swap-review-actions"><select data-swap-target="${sw.id}"><option value="">Zielperson wählen…</option>${opts}</select><button class="primary" data-swap="${sw.id}" data-status="approved">Genehmigen</button><button class="danger" data-swap="${sw.id}" data-status="rejected">Ablehnen</button></div>`:'';d.innerHTML=`<div><div class="title">${sh?.name||'Schicht'} · ${sh?.date?formatDateDE(sh.date):''}</div><div class="meta">${personBy(sw.requester_person_id)?.name||''} → ${personBy(sw.target_person_id)?.name||'offen'} · ${sw.status}${sw.notes?' · '+sw.notes:''}</div></div>${actions}`;box.appendChild(d)});$$('[data-swap]').forEach(b=>b.onclick=async()=>{const t=$(`[data-swap-target="${b.dataset.swap}"]`);const body={status:b.dataset.status};if(t?.value)body.target_person_id=t.value;try{await api('/api/swaps/'+b.dataset.swap,{method:'PATCH',body:JSON.stringify(body)});await load()}catch(err){alert(err.payload?.conflicts?.join('\n')||err.message)}})
}
function renderNotifications(){const box=$('#notificationList');if(!box)return;box.innerHTML='';const rows=(state.notifications||[]).filter(n=>n.user_id===state.current_user?.id).sort((a,b)=>(b.created_at||'').localeCompare(a.created_at||''));if(!rows.length){box.innerHTML='<div class="empty">Keine Benachrichtigungen.</div>';return}rows.forEach(n=>{const d=document.createElement('div');d.className='item notification-card '+(n.read?'':'notification-unread');d.innerHTML=`<div><div class="title">${n.message}</div><div class="meta">${(n.created_at||'').replace('T',' ')} · ${n.read?'Gelesen':'Neu'}</div></div>`;d.onclick=async()=>{if(!n.read){await api('/api/notifications/'+n.id,{method:'PATCH',body:JSON.stringify({read:true})});await load()}};box.appendChild(d)})}
function renderUsers(){
  const ps=$('#userPerson');if(ps){const cur=ps.value;ps.innerHTML='<option value="">Keine Verknüpfung</option>';state.people.forEach(p=>{const o=document.createElement('option');o.value=p.id;o.textContent=p.name;ps.appendChild(o)});ps.value=cur}
  const box=$('#userList');if(!box)return;box.innerHTML='';state.users.forEach(u=>{const d=document.createElement('div');d.className='item';d.innerHTML=`<div><div class="title">${u.display_name} (${u.username})</div><div class="meta">${u.role} · ${personBy(u.person_id)?.name||'keine Person'} · ${u.active===false?'deaktiviert':'aktiv'}</div></div>`;box.appendChild(d)})
}
if($('#showCalendarSubscription'))$('#showCalendarSubscription').onclick=()=>{$('#calendarSubscriptionPanel')?.classList.toggle('hidden');loadCalendarSubscription()};
if($('#copyCalendarSubscription'))$('#copyCalendarSubscription').onclick=async()=>{const v=$('#calendarSubscriptionUrl')?.value;if(!v)return;try{await navigator.clipboard.writeText(v);setStatus('Kalender-Link kopiert')}catch(e){prompt('Kalender-Link kopieren:',v)}};
if($('#regenerateCalendarSubscription'))$('#regenerateCalendarSubscription').onclick=async()=>{if(!confirm('Alten Kalender-Link ungültig machen und einen neuen erstellen?'))return;try{await api('/api/calendar-token/regenerate',{method:'POST',body:'{}'});await loadCalendarSubscription();setStatus('Kalender-Link erneuert')}catch(e){alert(e.message)}};
if($('#reminderSettingsForm'))$('#reminderSettingsForm').onsubmit=async e=>{e.preventDefault();const f=e.target,b=formJSON(f);b.automatic_reminders=f.elements.automatic_reminders.checked;try{await api('/api/settings/config',{method:'PATCH',body:JSON.stringify(b)});setStatus('Erinnerungen gespeichert');await load()}catch(err){alert(err.message)}};
if($('#runRemindersNow'))$('#runRemindersNow').onclick=async()=>{try{const x=await api('/api/run-reminders',{method:'POST',body:'{}'});setStatus(`${x.sent} Erinnerung(en) neu gesendet`);await load()}catch(e){alert(e.message)}};
if($('#notificationPreferencesForm'))$('#notificationPreferencesForm').onsubmit=async e=>{
  e.preventDefault();const f=e.target;
  try{
    const u=await api('/api/notification-preferences',{method:'POST',body:JSON.stringify({email_notifications:f.elements.email_notifications.checked,sms_notifications:f.elements.sms_notifications.checked})});
    state.current_user=u;setStatus('Benachrichtigungen gespeichert');await load()
  }catch(err){alert(err.message)}
};
if($('#smsSettingsForm'))$('#smsSettingsForm').onsubmit=async e=>{
  e.preventDefault();const f=e.target,b=formJSON(f);b.sms_enabled=f.elements.sms_enabled.checked;if(!b.sms_bearer_token)delete b.sms_bearer_token;
  try{await api('/api/settings/config',{method:'PATCH',body:JSON.stringify(b)});setStatus('SMS Gateway gespeichert');await load()}catch(err){alert(err.message)}
};
if($('#sendTestSms'))$('#sendTestSms').onclick=async()=>{
  try{await api('/api/test-sms',{method:'POST',body:JSON.stringify({to:$('#testSmsTo').value})});setStatus('Test-SMS gesendet');renderSmsStatus()}catch(err){alert(err.message)}
};
if($('#showPasswordReset'))$('#showPasswordReset').onclick=()=>$('#passwordResetPanel')?.classList.toggle('hidden');
if($('#requestPasswordReset'))$('#requestPasswordReset').onclick=async()=>{
  const username=$('#resetUsername').value.trim(),status=$('#passwordResetStatus');if(!username){status.textContent='Bitte Benutzername eingeben.';return}
  try{const x=await api('/api/request-password-reset',{method:'POST',body:JSON.stringify({username})});status.textContent=x.message||'Reset-Code wurde angefordert.'}
  catch(err){status.textContent=err.message}
};
if($('#completePasswordReset'))$('#completePasswordReset').onclick=async()=>{
  const username=$('#resetUsername').value.trim(),code=$('#resetCode').value.trim(),pw=$('#resetNewPassword').value,confirm=$('#resetConfirmPassword').value,status=$('#passwordResetStatus');
  if(pw!==confirm){status.textContent='Die neuen Passwörter stimmen nicht überein.';return}
  try{await api('/api/complete-password-reset',{method:'POST',body:JSON.stringify({username,code,new_password:pw})});status.textContent='Passwort erfolgreich zurückgesetzt. Du kannst dich jetzt anmelden.';$('#resetCode').value='';$('#resetNewPassword').value='';$('#resetConfirmPassword').value=''}
  catch(err){status.textContent=err.message}
};
if($('#emailSettingsForm'))$('#emailSettingsForm').onsubmit=async e=>{
  e.preventDefault();const f=e.target,b=formJSON(f);b.smtp_tls=f.elements.smtp_tls.checked;b.email_enabled=f.elements.email_enabled.checked;if(!b.smtp_password)delete b.smtp_password;
  try{await api('/api/settings/config',{method:'PATCH',body:JSON.stringify(b)});setStatus('SMTP gespeichert');await load()}catch(err){alert(err.message)}
};
if($('#sendTestEmail'))$('#sendTestEmail').onclick=async()=>{try{await api('/api/test-email',{method:'POST',body:JSON.stringify({to:$('#testEmailTo').value})});setStatus('Test-E-Mail gesendet');renderEmailStatus()}catch(err){alert(err.message)}};
if($('#shiftInfoShift'))$('#shiftInfoShift').onchange=loadShiftInfoForm;
if($('#shiftInfoForm'))$('#shiftInfoForm').onsubmit=async e=>{
  e.preventDefault();const body=formJSON(e.target),id=body.shift_id;delete body.shift_id;
  try{await api('/api/shifts/'+id,{method:'PATCH',body:JSON.stringify(body)});setStatus('Einsatzinfos gespeichert');await load()}catch(err){alert(err.message)}
};
if($('#cockpitEvent'))$('#cockpitEvent').onchange=renderEventCockpit;
if($('#reportEvent'))$('#reportEvent').onchange=renderReports;
if($('#downloadReportCsv'))$('#downloadReportCsv').onclick=downloadReportCsv;
if($('#skillForm'))$('#skillForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/skills',{method:'POST',body:JSON.stringify(formJSON(e.target))});e.target.reset();await load()}catch(err){alert(err.message)}};
if($('#skillPerson'))$('#skillPerson').onchange=renderSkillChecks;
if($('#skillShift'))$('#skillShift').onchange=renderSkillChecks;
if($('#savePersonSkills'))$('#savePersonSkills').onclick=async()=>{await api('/api/person-skills',{method:'POST',body:JSON.stringify({person_id:$('#skillPerson').value,skill_ids:[...$$('#personSkillChecks input:checked')].map(x=>x.value)})});await load()};
if($('#saveShiftSkills'))$('#saveShiftSkills').onclick=async()=>{await api('/api/shift-skills',{method:'POST',body:JSON.stringify({shift_id:$('#skillShift').value,skill_ids:[...$$('#shiftSkillChecks input:checked')].map(x=>x.value)})});await load()};
if($('#buildAutoPlan'))$('#buildAutoPlan').onclick=buildAutoPlan;
if($('#applyAutoPlan'))$('#applyAutoPlan').onclick=applyAutoPlan;
if($('#cloneEventForm'))$('#cloneEventForm').onsubmit=async e=>{
  e.preventDefault();const f=e.target,b=formJSON(f);['copy_shifts','copy_event_team','copy_assignments'].forEach(k=>b[k]=f.elements[k].checked);
  try{const x=await api('/api/clone-event',{method:'POST',body:JSON.stringify(b)});setStatus(`${x.event.name} erstellt · ${x.shifts_created} Schichten kopiert`);f.reset();await load()}catch(err){alert(err.message)}
};
if($('#eventPoolEvent'))$('#eventPoolEvent').onchange=renderEventPool;
if($('#saveEventPool'))$('#saveEventPool').onclick=async()=>{
  const event_id=$('#eventPoolEvent').value;
  const person_ids=[...$$('#eventPoolPeople input:checked')].map(x=>x.value);
  try{
    await api('/api/event-pool',{method:'POST',body:JSON.stringify({event_id,person_ids})});
    await api('/api/events/'+event_id,{method:'PATCH',body:JSON.stringify({signup_mode:$('#eventSignupMode').value})});
    setStatus('Event-Team gespeichert');await load()
  }catch(err){alert(err.message)}
};
if($('#passwordChangeForm'))$('#passwordChangeForm').onsubmit=async e=>{e.preventDefault();const body=formJSON(e.target);if(body.new_password!==body.confirm_password){alert('Die neuen Passwörter stimmen nicht überein.');return}try{await api('/api/change-password',{method:'POST',body:JSON.stringify(body)});e.target.reset();setStatus('Passwort geändert');await load()}catch(err){alert(err.message)}};
if($('#auditRefresh'))$('#auditRefresh').onclick=renderAuditLog;
if($('#auditSearch'))$('#auditSearch').oninput=()=>renderAuditLog();
if($('#refreshSuggestions'))$('#refreshSuggestions').onclick=renderStaffingSuggestions;
if($('#suggestionShift'))$('#suggestionShift').onchange=renderStaffingSuggestions;
if($('#planningSettingsForm'))$('#planningSettingsForm').onsubmit=async e=>{e.preventDefault();const body=formJSON(e.target);body.min_rest_hours=Number(body.min_rest_hours||0);body.weekly_warning_hours=Number(body.weekly_warning_hours||40);try{await api('/api/settings/config',{method:'PATCH',body:JSON.stringify(body)});setStatus('Planungsregeln gespeichert');await load()}catch(err){alert(err.message)}};
if($('#employeeAvailabilityForm'))$('#employeeAvailabilityForm').onsubmit=async e=>{e.preventDefault();const body=formJSON(e.target);try{await api('/api/availability',{method:'POST',body:JSON.stringify(body)});e.target.reset();await load()}catch(err){alert(err.message)}};
if($('#markAllNotificationsRead'))$('#markAllNotificationsRead').onclick=async()=>{const rows=(state.notifications||[]).filter(n=>n.user_id===state.current_user?.id&&!n.read);for(const n of rows)await api('/api/notifications/'+n.id,{method:'PATCH',body:JSON.stringify({read:true})});await load()};
if($('#availabilityForm'))$('#availabilityForm').onsubmit=async e=>{e.preventDefault();const body=formJSON(e.target);if(userRole()==='employee')delete body.person_id;await api('/api/availability',{method:'POST',body:JSON.stringify(body)});e.target.reset();await load()};
if($('#swapForm'))$('#swapForm').onsubmit=async e=>{e.preventDefault();await api('/api/swaps',{method:'POST',body:JSON.stringify(formJSON(e.target))});e.target.reset();await load()};
if($('#userForm'))$('#userForm').onsubmit=async e=>{e.preventDefault();await api('/api/users',{method:'POST',body:JSON.stringify(formJSON(e.target))});e.target.reset();await load()};

document.addEventListener('DOMContentLoaded',()=>{
  if(window.plannerDragPeopleFiltersBound)return;
  window.plannerDragPeopleFiltersBound=true;
  ['plannerEvent','plannerDate','plannerPerson'].forEach(id=>{
    const el=document.getElementById(id);
    if(el)el.addEventListener('change',()=>{
      renderPlannerFilters();
      renderPlannerPeoplePalette();
      renderShiftAssignmentBoard();
      renderDropBoard();
    });
  });
});


// v42 PWA installation and installability status.
let deferredPwaPrompt=null;

function pwaDisplayModeStandalone(){
  return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
}
function pwaSecureEnough(){
  return window.isSecureContext || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
}
function pwaPlatformHint(){
  const ua=navigator.userAgent||'';
  if(/iPhone|iPad|iPod/i.test(ua)) return 'iOS';
  if(/Android/i.test(ua)) return 'Android';
  return 'desktop';
}
function updatePwaInstallStatus(){
  const btn=$('#installPwaButton'), status=$('#pwaInstallStatus');
  if(!btn||!status)return;

  if(pwaDisplayModeStandalone()){
    btn.textContent='App installiert';
    btn.disabled=true;
    status.textContent='Die App läuft bereits im installierten Modus.';
    status.dataset.state='installed';
    return;
  }

  btn.disabled=false;
  btn.textContent='App installieren';

  if(deferredPwaPrompt){
    status.textContent='Bereit zur Installation.';
    status.dataset.state='ready';
    return;
  }

  if(!pwaSecureEnough()){
    status.textContent='HTTPS erforderlich, damit die App installiert werden kann.';
    status.dataset.state='warning';
    return;
  }

  const platform=pwaPlatformHint();
  if(platform==='iOS'){
    status.textContent='iPhone/iPad: In Safari „Teilen“ → „Zum Home-Bildschirm“.';
    status.dataset.state='info';
  }else if(platform==='Android'){
    status.textContent='Falls kein Installationsdialog erscheint: Browser-Menü → „App installieren“ oder „Zum Startbildschirm“.';
    status.dataset.state='info';
  }else{
    status.textContent='Falls kein Dialog erscheint, nutze im Browser-Menü „App installieren“.';
    status.dataset.state='info';
  }
}

window.addEventListener('beforeinstallprompt',e=>{
  e.preventDefault();
  deferredPwaPrompt=e;
  updatePwaInstallStatus();
});

window.addEventListener('appinstalled',()=>{
  deferredPwaPrompt=null;
  updatePwaInstallStatus();
});

if($('#installPwaButton'))$('#installPwaButton').onclick=async()=>{
  if(pwaDisplayModeStandalone()){
    updatePwaInstallStatus();
    return;
  }

  if(!pwaSecureEnough()){
    alert('Diese Seite muss über HTTPS geöffnet werden, damit sie als App installiert werden kann. Ausnahme: localhost.');
    return;
  }

  if(deferredPwaPrompt){
    deferredPwaPrompt.prompt();
    await deferredPwaPrompt.userChoice;
    deferredPwaPrompt=null;
    updatePwaInstallStatus();
    return;
  }

  const platform=pwaPlatformHint();
  if(platform==='iOS'){
    alert('Auf iPhone/iPad: Öffne die Seite in Safari, tippe auf „Teilen“ und dann auf „Zum Home-Bildschirm“.');
  }else if(platform==='Android'){
    alert('Dein Browser zeigt aktuell keinen direkten Installationsdialog. Öffne das Browser-Menü und wähle „App installieren“ oder „Zum Startbildschirm hinzufügen“.');
  }else{
    alert('Dein Browser zeigt aktuell keinen direkten Installationsdialog. Prüfe im Browser-Menü, ob „App installieren“ verfügbar ist.');
  }
};

function updateOnlineState(){
  const offline=!navigator.onLine;$('#offlineBanner')?.classList.toggle('hidden',!offline);
  document.body.classList.toggle('is-offline',offline);
}
window.addEventListener('online',()=>{updateOnlineState();load().catch(()=>{});updatePwaInstallStatus()});
window.addEventListener('offline',()=>{updateOnlineState();updatePwaInstallStatus()});
updateOnlineState();
updatePwaInstallStatus();

if('serviceWorker' in navigator){
  window.addEventListener('load',async()=>{
    try{
      const reg=await navigator.serviceWorker.register('./service-worker.js');
      await navigator.serviceWorker.ready;
      updatePwaInstallStatus();
      console.log('PWA service worker active',reg.scope);
    }catch(err){
      console.warn('PWA service worker registration failed',err);
      const status=$('#pwaInstallStatus');
      if(status && pwaSecureEnough()){
        status.textContent='Service Worker konnte nicht registriert werden.';
        status.dataset.state='warning';
      }
    }
  });
}

document.addEventListener('DOMContentLoaded',()=>{renderEnvironmentBanner();const dl=$('#calendarDownloadLink');if(dl)dl.href=apiUrl('/api/calendar.ics')});
